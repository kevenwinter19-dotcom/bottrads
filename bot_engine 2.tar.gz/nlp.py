class AnalisadorNLP:
    def __init__(self):
        self.score = 0.0
        self.label = "Neutro"
        self.total_noticias = 0
        self.top_termos = []

        self.positivos_fortes = {
            "breakout","approval","approved","adoption","partnership","surge",
            "rally","inflow","record","expansion","growth","recovery","bullish","bull"
        }
        self.positivos_leves = {
            "rebound","institutional","demand","stable","strength","momentum","accumulate"
        }

        self.negativos_fortes = {
            "hack","lawsuit","ban","fraud","crackdown","dump","selloff",
            "outflow","collapse","bearish","bear","liquidation","panic"
        }
        self.negativos_leves = {
            "dip","pullback","weak","rejection"
        }

    def _tokenizar(self, txt: str):
        txt = (txt or "").lower()
        for ch in ',.;:!?()[]{}"\'/\\|-_@#$%^&*=+`~':
            txt = txt.replace(ch, " ")
        return [w for w in txt.split() if len(w) > 2]

    def analisar_noticias(self, noticias):
        noticias = noticias or []
        self.total_noticias = len(noticias)

        score_total = 0.0
        termos_count = {}

        for item in noticias:
            title = item.get("title", "") or ""
            summary = item.get("summary", "") or ""

            title_tokens = self._tokenizar(title)
            summary_tokens = self._tokenizar(summary)
            tokens = title_tokens + summary_tokens

            item_score = 0.0

            for t in title_tokens:
                if t in self.positivos_fortes: item_score += 1.5
                elif t in self.positivos_leves: item_score += 0.35
                elif t in self.negativos_fortes: item_score -= 1.5
                elif t in self.negativos_leves: item_score -= 0.35

            for t in summary_tokens:
                if t in self.positivos_fortes: item_score += 0.7
                elif t in self.positivos_leves: item_score += 0.15
                elif t in self.negativos_fortes: item_score -= 0.7
                elif t in self.negativos_leves: item_score -= 0.15

            score_total += item_score

            for t in tokens:
                if t in self.positivos_fortes or t in self.positivos_leves or t in self.negativos_fortes or t in self.negativos_leves:
                    termos_count[t] = termos_count.get(t, 0) + 1

        self.score = round(score_total, 2)

        if self.score >= 3.5:
            self.label = "Bullish"
        elif self.score <= -3.5:
            self.label = "Bearish"
        else:
            self.label = "Neutro"

        self.top_termos = [k for k, _ in sorted(termos_count.items(), key=lambda x: x[1], reverse=True)[:8]]
        return {
            "score": self.score,
            "label": self.label,
            "total_noticias": self.total_noticias,
            "top_termos": self.top_termos,
        }

    def atualizar(self, noticias=None):
        return self.analisar_noticias(noticias or [])

    def ajustar_sinal(self, sinal, perfil="mid"):
        sinal = (sinal or "AGUARDAR").upper()
        perfil = (perfil or "mid").lower()

        limite = {
            "large": 5.0,
            "mid": 6.0,
            "small": 7.5,
        }.get(perfil, 6.0)

        if self.label == "Bearish" and self.score <= -limite and sinal == "COMPRAR":
            return "AGUARDAR"

        if self.label == "Bullish" and self.score >= limite and sinal == "VENDER":
            return "AGUARDAR"

        return sinal
