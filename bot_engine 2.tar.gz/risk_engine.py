from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict


def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default


@dataclass
class RiskPlan:
    stop: float
    alvo: float
    rr_min: float
    break_even_trigger_rr: float
    trailing_trigger_rr: float
    trailing_offset_rr: float
    trailing_mode: str
    motivo: str

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


class RiskEngine:
    """
    Compatível com engine atual.
    Interface esperada:
      build_plan(acao, preco, atr, df_m15, contexto, flow_proxy, whale_real, news_snapshot, preset)
      update_management(pos, df_m15, atr_m15)
    """

    def __init__(self) -> None:
        pass

    def build_plan(
        self,
        acao: str,
        preco: float,
        atr: float,
        df_m15: Any,
        contexto: Dict[str, Any],
        flow_proxy: Dict[str, Any],
        whale_real: Dict[str, Any],
        news_snapshot: Dict[str, Any],
        preset: str = "equilibrado",
    ) -> RiskPlan:
        acao = str(acao or "AGUARDAR").upper()
        preco = _safe_float(preco)
        atr = max(_safe_float(atr), preco * 0.001)

        if preset == "conservador":
            rr_min = 1.40
            be_rr = 1.10
            trail_rr = 1.40
            trail_off = 0.55
        elif preset == "agressivo":
            rr_min = 1.15
            be_rr = 0.90
            trail_rr = 1.10
            trail_off = 0.75
        else:
            rr_min = 1.25
            be_rr = 1.00
            trail_rr = 1.25
            trail_off = 0.65

        swing_low = None
        swing_high = None
        try:
            swing_low = float(df_m15.tail(20)["low"].min())
            swing_high = float(df_m15.tail(20)["high"].max())
        except Exception:
            pass

        regime = str((contexto or {}).get("regime") or "range").lower()
        trend_mode = "trend" if "trend" in regime else "range"

        if acao == "COMPRAR":
            ref = swing_low if swing_low is not None else preco - atr * 1.2
            stop = ref - atr * 0.35
            alvo = preco + max((preco - stop) * max(rr_min, 1.4 if trend_mode == "trend" else rr_min), atr * 1.0)
        elif acao == "VENDER":
            ref = swing_high if swing_high is not None else preco + atr * 1.2
            stop = ref + atr * 0.35
            alvo = preco - max((stop - preco) * max(rr_min, 1.4 if trend_mode == "trend" else rr_min), atr * 1.0)
        else:
            stop = preco - atr
            alvo = preco + atr

        motivo = f"{trend_mode} | preset {preset}"

        return RiskPlan(
            stop=round(stop, 8),
            alvo=round(alvo, 8),
            rr_min=round(rr_min, 4),
            break_even_trigger_rr=round(be_rr, 4),
            trailing_trigger_rr=round(trail_rr, 4),
            trailing_offset_rr=round(trail_off, 4),
            trailing_mode="pivot_plus_atr" if trend_mode == "trend" else "atr_guard",
            motivo=motivo,
        )

    def update_management(self, pos: Dict[str, Any], df_m15: Any, atr_m15: float) -> None:
        try:
            if not pos:
                return
            atr_m15 = max(_safe_float(atr_m15), 0.0)
            if atr_m15 <= 0:
                return

            lado = str(pos.get("lado") or "").upper()
            entrada = _safe_float(pos.get("entrada"))
            stop = _safe_float(pos.get("stop"))
            alvo = _safe_float(pos.get("alvo"))
            preco_atual = None
            try:
                preco_atual = float(df_m15.iloc[-1]["close"])
            except Exception:
                preco_atual = None

            if not preco_atual or not entrada or not stop:
                return

            risco = abs(entrada - stop)
            if risco <= 0:
                return

            pnl_r = ((preco_atual - entrada) / risco) if lado == "COMPRAR" else ((entrada - preco_atual) / risco)

            if pnl_r >= _safe_float(pos.get("break_even_trigger_rr", 1.0), 1.0) and not pos.get("break_even_ativo"):
                pos["stop"] = entrada
                pos["break_even_ativo"] = True

            if pnl_r >= _safe_float(pos.get("trailing_trigger_rr", 1.25), 1.25):
                off = _safe_float(pos.get("trailing_offset_rr", 0.65), 0.65)
                dist = risco * off
                if lado == "COMPRAR":
                    novo_stop = max(_safe_float(pos.get("stop")), preco_atual - dist)
                else:
                    novo_stop = min(_safe_float(pos.get("stop")), preco_atual + dist)
                pos["stop"] = round(novo_stop, 8)
                pos["trailing_ativo"] = True

            pos.setdefault("trailing_mode", pos.get("trailing_mode", "atr_guard"))
            pos.setdefault("break_even_ativo", False)
            pos.setdefault("trailing_ativo", False)
        except Exception:
            pass
