import pandas as pd

def ema(series, period):
    return series.ewm(span=period, adjust=False).mean()

def calcular_contexto_mercado(df_m15: pd.DataFrame, df_h1: pd.DataFrame, preco_atual: float, atr_atual: float):
    if df_m15 is None or df_h1 is None or len(df_m15) < 50 or len(df_h1) < 50:
        return {
            "high_24h": preco_atual,
            "low_24h": preco_atual,
            "high_7d": preco_atual,
            "low_7d": preco_atual,
            "range_pos_24h": 0.5,
            "range_pos_7d": 0.5,
            "ema21": preco_atual,
            "ema50": preco_atual,
            "ema200": preco_atual,
            "dist_ema21_pct": 0.0,
            "atr_medio": atr_atual,
            "atr_ratio": 1.0,
            "regime": "indefinido",
            "esticado": False,
        }

    closes_h1 = df_h1["close"].astype(float)
    highs_h1 = df_h1["high"].astype(float)
    lows_h1 = df_h1["low"].astype(float)

    ema21 = float(ema(closes_h1, 21).iloc[-1])
    ema50 = float(ema(closes_h1, 50).iloc[-1])
    ema200 = float(ema(closes_h1, 200).iloc[-1]) if len(closes_h1) >= 200 else float(ema(closes_h1, 50).iloc[-1])

    high_24h = float(highs_h1.tail(24).max()) if len(highs_h1) >= 24 else float(highs_h1.max())
    low_24h = float(lows_h1.tail(24).min()) if len(lows_h1) >= 24 else float(lows_h1.min())

    high_7d = float(highs_h1.tail(24 * 7).max()) if len(highs_h1) >= 24 else float(highs_h1.max())
    low_7d = float(lows_h1.tail(24 * 7).min()) if len(lows_h1) >= 24 else float(lows_h1.min())

    range_24h = max(high_24h - low_24h, 1e-9)
    range_7d = max(high_7d - low_7d, 1e-9)

    range_pos_24h = (preco_atual - low_24h) / range_24h
    range_pos_7d = (preco_atual - low_7d) / range_7d

    dist_ema21_pct = ((preco_atual - ema21) / ema21) * 100 if ema21 else 0.0

    tr = (highs_h1 - lows_h1).tail(30)
    atr_medio = float(tr.mean()) if len(tr) else float(atr_atual)
    atr_ratio = float(atr_atual / atr_medio) if atr_medio > 0 else 1.0

    regime = "range"
    if preco_atual > ema21 > ema50 and ema21 > ema200:
        regime = "tendencia_alta"
    elif preco_atual < ema21 < ema50 and ema21 < ema200:
        regime = "tendencia_baixa"
    elif range_pos_24h > 0.85 and dist_ema21_pct > 2.0:
        regime = "esticado_cima"
    elif range_pos_24h < 0.15 and dist_ema21_pct < -2.0:
        regime = "esticado_baixo"

    esticado = abs(dist_ema21_pct) >= 3.5

    return {
        "high_24h": round(high_24h, 8),
        "low_24h": round(low_24h, 8),
        "high_7d": round(high_7d, 8),
        "low_7d": round(low_7d, 8),
        "range_pos_24h": round(range_pos_24h, 4),
        "range_pos_7d": round(range_pos_7d, 4),
        "ema21": round(ema21, 8),
        "ema50": round(ema50, 8),
        "ema200": round(ema200, 8),
        "dist_ema21_pct": round(dist_ema21_pct, 4),
        "atr_medio": round(atr_medio, 8),
        "atr_ratio": round(atr_ratio, 4),
        "regime": regime,
        "esticado": esticado,
    }
