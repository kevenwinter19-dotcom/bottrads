from .flow_proxy import FlowProxyDetector


class WhaleDetector(FlowProxyDetector):
    """Compatibilidade com a base antiga.

    A lógica antiga de whale agora é tratada como proxy de fluxo.
    """

    pass

