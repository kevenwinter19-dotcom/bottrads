from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List

from .trade_journal import TradeJournal


class LearningEngine:
    def __init__(self, journal: TradeJournal, summary_path: str = "data/learning_summary.json"):
        self.journal = journal
        self.summary_path = Path(summary_path)
        self.summary_path.parent.mkdir(parents=True, exist_ok=True)
        self.summary: Dict[str, Any] = {}

    def refresh_summary_from_journal(self, limit: int = 300) -> Dict[str, Any]:
        rows = self.journal.read_all(limit=limit)
        total = len(rows)
        wins = 0
        losses = 0
        by_pair: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            "trades": 0, "wins": 0, "losses": 0, "pnl_liquido": 0.0
        })
        error_counter: Counter[str] = Counter()
        conf_buckets = {"low": {"trades": 0, "wins": 0}, "mid": {"trades": 0, "wins": 0}, "high": {"trades": 0, "wins": 0}}

        for x in rows:
            pnl = float(x.get("pnl_liquido", 0.0) or 0.0)
            par = str(x.get("par", "") or "").upper() or "UNKNOWN"
            cls = str(x.get("classe_erro", "") or "n/a")
            conf = float(x.get("ia_confianca", 0.0) or 0.0)

            by_pair[par]["trades"] += 1
            by_pair[par]["pnl_liquido"] += pnl

            if pnl > 0:
                wins += 1
                by_pair[par]["wins"] += 1
            else:
                losses += 1
                by_pair[par]["losses"] += 1
                error_counter[cls] += 1

            if conf < 0.55:
                bucket = "low"
            elif conf < 0.75:
                bucket = "mid"
            else:
                bucket = "high"
            conf_buckets[bucket]["trades"] += 1
            if pnl > 0:
                conf_buckets[bucket]["wins"] += 1

        top_errors = [{"classe": k, "count": v} for k, v in error_counter.most_common(8)]

        pair_stats = []
        for par, st in by_pair.items():
            wr = (st["wins"] / st["trades"] * 100.0) if st["trades"] else 0.0
            pair_stats.append({
                "par": par,
                **st,
                "winrate": round(wr, 2),
                "pnl_liquido": round(float(st["pnl_liquido"]), 4),
            })
        pair_stats.sort(key=lambda x: (x["winrate"], x["pnl_liquido"], x["trades"]), reverse=True)

        conf_stats = {}
        for k, st in conf_buckets.items():
            wr = (st["wins"] / st["trades"] * 100.0) if st["trades"] else 0.0
            conf_stats[k] = {"trades": st["trades"], "wins": st["wins"], "winrate": round(wr, 2)}

        self.summary = {
            "trades_total": total,
            "wins": wins,
            "losses": losses,
            "winrate_total": round((wins / total * 100.0) if total else 0.0, 2),
            "top_errors": top_errors,
            "pair_stats": pair_stats[:12],
            "confidence_stats": conf_stats,
        }
        self.summary_path.write_text(json.dumps(self.summary, ensure_ascii=False, indent=2), encoding="utf-8")
        return self.summary

    def load_summary(self) -> Dict[str, Any]:
        if self.summary:
            return self.summary
        if self.summary_path.exists():
            try:
                self.summary = json.loads(self.summary_path.read_text(encoding="utf-8"))
            except Exception:
                self.summary = {}
        return self.summary

    def get_prompt_context(self, par: str, limit_recent_pair: int = 12) -> Dict[str, Any]:
        par = str(par or "").upper()
        summary = self.load_summary()
        pair_recent = self.journal.recent_for_pair(par, limit=limit_recent_pair)

        pair_wins = sum(1 for x in pair_recent if float(x.get("pnl_liquido", 0.0) or 0.0) > 0)
        pair_total = len(pair_recent)
        pair_wr = round((pair_wins / pair_total * 100.0) if pair_total else 0.0, 2)

        recent_errors = Counter(
            str(x.get("classe_erro", "") or "n/a")
            for x in pair_recent
            if float(x.get("pnl_liquido", 0.0) or 0.0) <= 0
        )

        return {
            "global": {
                "trades_total": summary.get("trades_total", 0),
                "winrate_total": summary.get("winrate_total", 0.0),
                "top_errors": summary.get("top_errors", [])[:5],
                "confidence_stats": summary.get("confidence_stats", {}),
            },
            "pair": {
                "par": par,
                "recent_trades": pair_total,
                "recent_winrate": pair_wr,
                "recent_error_classes": [{"classe": k, "count": v} for k, v in recent_errors.most_common(4)],
            }
        }
