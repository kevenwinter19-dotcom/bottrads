from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class AITradePlan:
    executar: bool
    acao: str
    confianca: float
    stop_loss: float
    take_profit: float
    break_even_trigger: float
    trailing_ativar: bool
    trailing_dist_atr: float
    saida_parcial_ativar: bool
    saida_parcial_pct: float
    saida_parcial_rr: float
    motivo: str
    risco_ok: bool


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _f(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default


class AITradeOperator:
    def __init__(self, ai_engine: Any = None):
        self.ai_engine = ai_engine
        self.last_plan: Dict[str, Any] = {}

    def build_context(
        self,
        par: str,
        sinal: str,
        score_total: float,
        preco: float,
        atr: float,
        flow_info: Dict[str, Any],
        whale_info: Dict[str, Any],
        news_snapshot: Dict[str, Any],
        sentimento: Any,
        nlp: Any,
        rl_acao: str,
        risk_plan: Any,
        posicoes_abertas: int,
        contexto_extra: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:
        return {
            "par": par,
            "sinal": sinal,
            "score_total": score_total,
            "preco": preco,
            "atr": atr,
            "flow_info": flow_info or {},
            "whale_info": whale_info or {},
            "news_snapshot": news_snapshot or {},
            "sentimento": {
                "fear_greed": getattr(sentimento, "valor", None),
                "classificacao": getattr(sentimento, "classificacao", None),
                "fear_news": getattr(sentimento, "news", None),
                "classificacao_news": getattr(sentimento, "classificacao_news", None),
            },
            "nlp": {
                "score": getattr(nlp, "score", None),
                "label": getattr(nlp, "label", None),
            },
            "rl_acao": rl_acao,
            "risk_plan": {
                "stop": getattr(risk_plan, "stop", None),
                "take": getattr(risk_plan, "take", None),
                "rr": getattr(risk_plan, "rr", None),
            },
            "posicoes_abertas": posicoes_abertas,
            "contexto_extra": contexto_extra or {},
        }


    def build_manage_context(
        self,
        par: str,
        pos: Dict[str, Any],
        preco: float,
        atr: float,
        flow_info: Dict[str, Any],
        whale_info: Dict[str, Any],
        news_snapshot: Dict[str, Any],
        sentimento: Any,
        nlp: Any,
        contexto_extra: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:
        return {
            "par": par,
            "pos": dict(pos or {}),
            "preco": preco,
            "atr": atr,
            "flow_info": flow_info or {},
            "whale_info": whale_info or {},
            "news_snapshot": news_snapshot or {},
            "sentimento": {
                "fear_greed": getattr(sentimento, "valor", None),
                "classificacao": getattr(sentimento, "classificacao", None),
                "fear_news": getattr(sentimento, "news", None),
                "classificacao_news": getattr(sentimento, "classificacao_news", None),
            },
            "nlp": {
                "score": getattr(nlp, "score", None),
                "label": getattr(nlp, "label", None),
            },
            "contexto_extra": contexto_extra or {},
        }

    def request_manage_plan(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        pos = ctx.get("pos") or {}
        lado = str(pos.get("lado", pos.get("tipo", "COMPRAR"))).upper()
        preco = _f(ctx.get("preco"), 0.0)
        atr = max(_f(ctx.get("atr"), 0.0), 1e-9)
        entrada = _f(pos.get("entrada", pos.get("preco_entrada", 0.0)), 0.0)
        news_conflict = bool((ctx.get("news_snapshot") or {}).get("conflicts_with_trade", False))

        pnl_pct = 0.0
        if entrada > 0 and preco > 0:
            pnl_pct = ((preco - entrada) / entrada) if lado == "COMPRAR" else ((entrada - preco) / entrada)

        mover_stop = False
        novo_stop = _f(pos.get("stop"), entrada)
        mover_take = False
        novo_take = _f(pos.get("alvo", pos.get("take", preco)), preco)
        parcial = False
        parcial_pct = 0.5
        break_even_ativar = False
        fechar_total = False
        trailing_ativar = False
        trailing_dist_atr = 0.8
        motivo = "gestão tática neutra"

        if news_conflict:
            fechar_total = True
            motivo = "notícia passou a conflitar com a posição"
        elif pnl_pct > 0.006:
            break_even_ativar = True
            mover_stop = True
            novo_stop = entrada
            motivo = "posição em lucro, mover para break-even"
        elif pnl_pct > 0.012:
            trailing_ativar = True
            mover_stop = True
            mover_take = True
            if not bool(pos.get("parcial_executada", False)) and pnl_pct > 0.018:
                parcial = True
                parcial_pct = 0.5
            if lado == "COMPRAR":
                novo_stop = max(_f(pos.get("stop"), entrada), preco - 1.1 * atr)
                novo_take = max(_f(pos.get("alvo", preco), preco), preco + 2.2 * atr)
            else:
                novo_stop = min(_f(pos.get("stop"), entrada), preco + 1.1 * atr)
                novo_take = min(_f(pos.get("alvo", preco), preco), preco - 2.2 * atr)
            motivo = "lucro avançou, apertar stop e recalibrar alvo"
        elif pnl_pct < -0.012:
            fechar_total = True
            motivo = "degradação tática da posição"

        plan = {
            "manter": not fechar_total,
            "fechar_total": fechar_total,
            "mover_stop": mover_stop,
            "novo_stop": novo_stop,
            "mover_take": mover_take,
            "novo_take": novo_take,
            "parcial": parcial,
            "parcial_pct": parcial_pct,
            "break_even_ativar": break_even_ativar,
            "trailing_ativar": trailing_ativar,
            "trailing_dist_atr": trailing_dist_atr,
            "motivo": motivo,
        }
        self.last_plan = dict(self.last_plan or {})
        self.last_plan["manage"] = plan
        return plan

    def request_plan(self, ctx: Dict[str, Any]) -> AITradePlan:
        acao = str(ctx.get("sinal", "AGUARDAR")).upper()
        preco = _f(ctx.get("preco"), 0.0)
        atr = max(_f(ctx.get("atr"), 0.0), 1e-9)
        score = abs(_f(ctx.get("score_total"), 0.0))
        conflito_news = bool((ctx.get("news_snapshot") or {}).get("conflicts_with_trade", False))

        executar = acao in ("COMPRAR", "VENDER") and not conflito_news

        if acao == "COMPRAR":
            stop = preco - (1.6 * atr)
            take = preco + (2.8 * atr)
            be = preco + (1.0 * atr)
        elif acao == "VENDER":
            stop = preco + (1.6 * atr)
            take = preco - (2.8 * atr)
            be = preco - (1.0 * atr)
        else:
            stop = preco
            take = preco
            be = preco

        conf = _clamp(0.55 + min(score / 20.0, 0.25), 0.05, 0.95)
        motivo = "plano tatico fallback por ATR/score/contexto"
        if conflito_news:
            motivo = "noticia conflita com o trade"

        plan = AITradePlan(
            executar=executar,
            acao=acao,
            confianca=conf,
            stop_loss=stop,
            take_profit=take,
            break_even_trigger=be,
            trailing_ativar=True,
            trailing_dist_atr=0.8,
            saida_parcial_ativar=True,
            saida_parcial_pct=0.5,
            saida_parcial_rr=1.2,
            motivo=motivo,
            risco_ok=executar,
        )
        self.last_plan = plan.__dict__.copy()
        return plan
