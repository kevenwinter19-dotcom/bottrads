from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import json
import hmac

from .config import TEMPLATES_DIR, STATE_LOCK, SECRETS_LOCK, SECRETS, save_secrets, load_secrets, get_port
from .state import ESTADO_GLOBAL
from .logging_setup import log
from .bybit_v5 import BybitV5

DASHBOARD_FILE = TEMPLATES_DIR / "dashboard_admin.html"


def secure_compare(a: str, b: str) -> bool:
    return hmac.compare_digest((a or "").encode(), (b or "").encode())


def _to_bool(v):
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("1", "true", "yes", "on", "sim")



class DashboardHandler(BaseHTTPRequestHandler):
    def _send_json(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.wfile.flush()
        self.close_connection = True

    def _send_html(self, html, code=200):
        body = html.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.wfile.flush()
        self.close_connection = True

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        if not raw:
            return {}
        return json.loads(raw.decode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Connection", "close")
        self.end_headers()

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/api/estado":
            with STATE_LOCK, SECRETS_LOCK:
                payload = dict(ESTADO_GLOBAL)
                payload["capital_inicial"] = ESTADO_GLOBAL.get("capital_inicial", SECRETS.get("capital_total", 100.0))
                try:
                    if str(SECRETS.get("exchange", "binance")).lower() == "bybit":
                        data = bybit_wallet_balance("UNIFIED")
                        rows = (((data or {}).get("result") or {}).get("list") or [])
                        saldo = 0.0
                        if rows:
                            row = rows[0] or {}
                            for key in ("totalAvailableBalance", "totalWalletBalance"):
                                val = row.get(key)
                                if val not in (None, "", "0", "0.0"):
                                    try:
                                        saldo = float(val)
                                        break
                                    except Exception:
                                        pass
                            if saldo <= 0:
                                for coin in (row.get("coin") or []):
                                    if str(coin.get("coin", "")).upper() == "USDT":
                                        for key in ("availableToWithdraw", "walletBalance", "equity"):
                                            val = coin.get(key)
                                            if val not in (None, "", "0", "0.0"):
                                                try:
                                                    saldo = float(val)
                                                    break
                                                except Exception:
                                                    pass
                                        if saldo > 0:
                                            break

                        payload["capital"] = {
                            "saldo_usdt": saldo,
                            "valor_trade": float(SECRETS.get("futures_entry_usdt", 10.0) or 10.0)
                        }
                        payload["capital_inicial"] = saldo
                except Exception:
                    pass
                try:
                    cap_state = ESTADO_GLOBAL.get("capital") or {}
                    saldo_real = cap_state.get("saldo_usdt")
                    if saldo_real is not None:
                        payload["capital_inicial"] = float(saldo_real)
                except Exception:
                    pass

                payload["daily_loss_limit"] = ESTADO_GLOBAL.get("daily_loss_limit", SECRETS.get("daily_loss_limit", 50.0))
                payload["alpha_vantage_api_key"] = SECRETS.get("alpha_vantage_api_key", "")
                payload["finnhub_api_key"] = SECRETS.get("finnhub_api_key", "")
                payload["newsapi_api_key"] = SECRETS.get("newsapi_api_key", "")
                payload["openai_api_key"] = SECRETS.get("openai_api_key", "")
                payload["openai_model"] = SECRETS.get("openai_model", "gpt-5.4")
                payload["openai_enabled"] = bool(SECRETS.get("openai_enabled", False))
                payload["ai_provider"] = SECRETS.get("ai_provider", "openai")
                exchange_now = str(SECRETS.get("exchange", "binance")).lower()
                payload["exchange"] = exchange_now
                if exchange_now == "bybit":
                    payload["binance_api_key"] = SECRETS.get("bybit_api_key", "")
                    payload["binance_api_secret"] = SECRETS.get("bybit_api_secret", "")
                else:
                    payload["binance_api_key"] = SECRETS.get("binance_api_key", "")
                    payload["binance_api_secret"] = SECRETS.get("binance_api_secret", "")
                payload["bybit_api_key"] = SECRETS.get("bybit_api_key", "")
                payload["bybit_api_secret"] = SECRETS.get("bybit_api_secret", "")
                payload["trading_preset"] = str(SECRETS.get("trading_preset", "equilibrado")).lower()
                payload["trading_mode"] = str(SECRETS.get("trading_mode", "spot")).lower()
                payload["futures_leverage"] = int(SECRETS.get("futures_leverage", 1) or 1)
                payload["futures_allow_short"] = bool(SECRETS.get("futures_allow_short", False))
                payload["futures_margin_type"] = str(SECRETS.get("futures_margin_type", "ISOLATED")).upper()
                payload["futures_entry_usdt"] = float(SECRETS.get("futures_entry_usdt", 10.0) or 10.0)
                payload["futures_positions"] = ESTADO_GLOBAL.get("futures_positions", {})
                payload["bybit_positions_raw"] = ESTADO_GLOBAL.get("bybit_positions_raw") or []
                payload["bybit_open_orders_raw"] = ESTADO_GLOBAL.get("bybit_open_orders_raw") or []
                payload["bybit_wallet_raw"] = ESTADO_GLOBAL.get("bybit_wallet_raw") or {}
                payload["ai_last_decision"] = ESTADO_GLOBAL.get("ai_last_decision", {})
                payload["ai_trade_plan"] = ESTADO_GLOBAL.get("ai_trade_plan", {})
                payload["ai_last_decision"] = ESTADO_GLOBAL.get("ai_last_decision", {})
                payload["ai_manage_motivo"] = ESTADO_GLOBAL.get("ai_manage_motivo", "")
                payload["ai_entry_cooldown_sec"] = SECRETS.get("ai_entry_cooldown_sec", 180)
                payload["ai_manage_cooldown_sec"] = SECRETS.get("ai_manage_cooldown_sec", 60)
                payload["ai_manage_motivo"] = ESTADO_GLOBAL.get("ai_manage_motivo", "")
                payload["posicoes_abertas"] = ESTADO_GLOBAL.get("posicoes_abertas", {})
                payload["ai_entry_cooldown_sec"] = SECRETS.get("ai_entry_cooldown_sec", 180)
                payload["ai_manage_cooldown_sec"] = SECRETS.get("ai_manage_cooldown_sec", 60)
                # OAI_FINAL_BYBIT_CAPITAL_OVERRIDE
                try:
                    if str(SECRETS.get("exchange", "binance")).lower() == "bybit":
                        b = BybitV5(
                            api_key=str(SECRETS.get("bybit_api_key", "") or ""),
                            api_secret=str(SECRETS.get("bybit_api_secret", "") or ""),
                            testnet=bool(SECRETS.get("bybit_testnet", True)),
                        )
                        wb = b.wallet_balance("UNIFIED", "USDT")
                        rows = (((wb or {}).get("result") or {}).get("list") or [])
                        saldo = 0.0
                        if rows:
                            row = rows[0] or {}
                            for key in ("totalAvailableBalance", "totalWalletBalance"):
                                val = row.get(key)
                                if val not in (None, "", "0", "0.0"):
                                    try:
                                        saldo = float(val)
                                        break
                                    except Exception:
                                        pass
                            if saldo <= 0:
                                for coin in (row.get("coin") or []):
                                    if str(coin.get("coin", "")).upper() == "USDT":
                                        for key in ("availableToWithdraw", "walletBalance", "equity"):
                                            val = coin.get(key)
                                            if val not in (None, "", "0", "0.0"):
                                                try:
                                                    saldo = float(val)
                                                    break
                                                except Exception:
                                                    pass
                                        if saldo > 0:
                                            break

                        payload["capital"] = {
                            "saldo_usdt": saldo,
                            "valor_trade": float(SECRETS.get("futures_entry_usdt", 10.0) or 10.0)
                        }
                        payload["capital_inicial"] = saldo
                except Exception as e:
                    log.error("Falha override capital Bybit no dashboard: %s", e)
                # OAI_BYBIT_CAPITAL_FIX
                try:
                    if str(SECRETS.get("exchange", "binance")).lower() == "bybit":
                        b = BybitV5(
                            api_key=str(SECRETS.get("bybit_api_key", "") or ""),
                            api_secret=str(SECRETS.get("bybit_api_secret", "") or ""),
                            testnet=bool(SECRETS.get("bybit_testnet", True)),
                        )
                        wb = b.wallet_balance("UNIFIED", "USDT")
                        rows = (((wb or {}).get("result") or {}).get("list") or [])
                        saldo = 0.0
                        if rows:
                            row = rows[0] or {}
                            for key in ("totalAvailableBalance", "totalWalletBalance"):
                                val = row.get(key)
                                if val not in (None, "", "0", "0.0"):
                                    try:
                                        saldo = float(val)
                                        break
                                    except Exception:
                                        pass
                            if saldo <= 0:
                                coins = row.get("coin") or []
                                if isinstance(coins, list):
                                    for c in coins:
                                        if str(c.get("coin", "")).upper() == "USDT":
                                            for key in ("walletBalance", "equity", "availableToWithdraw"):
                                                val = c.get(key)
                                                if val not in (None, "", "0", "0.0"):
                                                    try:
                                                        saldo = float(val)
                                                        break
                                                    except Exception:
                                                        pass
                                            if saldo > 0:
                                                break

                        cap_state = payload.get("capital") or {}
                        payload["capital"] = {
                            "saldo_usdt": saldo,
                            "valor_trade": cap_state.get("valor_trade", float(SECRETS.get("futures_entry_usdt", 10.0) or 10.0))
                        }
                        payload["capital_inicial"] = saldo
                except Exception:
                    pass
                payload["mode_current"] = {
                    "trading_mode": str(SECRETS.get("trading_mode", "spot")).lower(),
                    "futures_leverage": int(SECRETS.get("futures_leverage", 1) or 1),
                    "futures_margin_type": str(SECRETS.get("futures_margin_type", "ISOLATED")).upper(),
                    "futures_allow_short": bool(SECRETS.get("futures_allow_short", False)),
                    "exchange": str(SECRETS.get("exchange", "binance")).lower(),
                }
                payload["futures_last_attempt"] = ESTADO_GLOBAL.get("futures_last_attempt", {})
                payload["bot_ativo"] = bool(SECRETS.get("bot_enabled_manual", True))
                payload["bot_pause_reason"] = ESTADO_GLOBAL.get("bot_pause_reason", "")
                payload["bot_status_label"] = ESTADO_GLOBAL.get("bot_status_label", "OPERANDO")
                payload["claude_last_decision"] = ESTADO_GLOBAL.get("claude_last_decision", {})
                payload["ai_last_decision"] = ESTADO_GLOBAL.get("ai_last_decision", payload["claude_last_decision"])
                payload["whale_alertas"] = list(ESTADO_GLOBAL.get("whale_alertas", []) or [])
                payload["whale_real_alertas"] = list(ESTADO_GLOBAL.get("whale_real_alertas", []) or [])
                payload["whale_orders_total"] = len(payload["whale_alertas"])
                payload["whale_activity"] = payload["whale_real_alertas"] or payload["whale_alertas"]
                payload["sniper_mode"] = str(SECRETS.get("sniper_mode", "off")).lower()

                itens = payload.get("news_items", []) or []
                payload["news_items"] = [
                    {
                        "pair": x.get("pair"),
                        "score": x.get("score"),
                        "title": x.get("title"),
                        "source": x.get("source"),
                        "summary": (x.get("summary") or "")[:180],
                        "time_published": x.get("time_published"),
                        "overall_sentiment_label": x.get("overall_sentiment_label"),
                        "image_url": x.get("image_url"),
                        "url": x.get("url"),
                    }
                    for x in itens[:8]
                ]
                logs = payload.get("log_recente", []) or []
                payload["log_recente"] = logs[-40:]
                manual_enabled = bool(SECRETS.get("bot_enabled_manual", True))
                payload["bot_ativo"] = manual_enabled
                if not manual_enabled:
                    payload["bot_status_label"] = "DESLIGADO"
                    payload["bot_pause_reason"] = "Bot desligado manualmente"
                else:
                    payload["bot_status_label"] = ESTADO_GLOBAL.get("bot_status_label", "OPERANDO")
                    payload["bot_pause_reason"] = ESTADO_GLOBAL.get("bot_pause_reason", "Bot operando normalmente")

                try:
                    bridge_path = Path("/tmp/ai_bridge_state.json")
                    if bridge_path.exists():
                        bridge = json.loads(bridge_path.read_text(encoding="utf-8"))
                        payload["ai_last_decision"] = bridge.get("ai_last_decision", {})
                        ultimo = payload.get("ultimo_sinal") or {}
                        pairs = bridge.get("pairs", {}) or {}
                        for par, ai in pairs.items():
                            if par in ultimo and isinstance(ultimo[par], dict):
                                ultimo[par]["ai_decision"] = ai
                        payload["ultimo_sinal"] = ultimo
                except Exception:
                    pass

                
                try:
                    from pathlib import Path
                    p = Path("/tmp/capital_state.json")
                    if p.exists():
                        capital = json.loads(p.read_text())
                        payload["capital"] = capital
                except:
                    pass

            
            try:
                fund_path = Path("/tmp/fund_state.json")
                if fund_path.exists():
                    fund = json.loads(fund_path.read_text(encoding="utf-8"))
                    payload["fund"] = fund
            except Exception:
                pass

            try:
                log_path = Path("/home/ubuntu/bot-ultra-v4-profissional/app.out")
                trade_status = {}
                if log_path.exists():
                    lines = log_path.read_text(encoding="utf-8", errors="ignore").splitlines()[-300:]

                    last_try = None
                    last_err = None
                    last_spot_only = None
                    last_sent = None

                    for line in reversed(lines):
                        if last_try is None and "Tentando ordem" in line:
                            last_try = line
                        if last_err is None and ("insufficient balance" in line.lower() or "erro " in line.lower() or "invalid api-key" in line.lower()):
                            last_err = line
                        if last_spot_only is None and "Spot-only:" in line:
                            last_spot_only = line
                        if last_sent is None and "Ordem enviada" in line:
                            last_sent = line
                        if last_try and (last_err or last_spot_only or last_sent):
                            break

                    if last_try:
                        trade_status["last_try"] = last_try
                    if last_err:
                        trade_status["last_error"] = last_err
                    if last_spot_only:
                        trade_status["spot_only"] = last_spot_only
                    if last_sent:
                        trade_status["last_sent"] = last_sent

                payload["trade_status"] = trade_status

                # OAI_SYNC_CAPITAL_OBJECT_WITH_CAPITAL_INICIAL
                try:
                    cap_obj = payload.get("capital") or {}
                    if not isinstance(cap_obj, dict):
                        cap_obj = {}
                    saldo_obj = float(cap_obj.get("saldo_usdt", 0.0) or 0.0)
                    saldo_ini = float(payload.get("capital_inicial", 0.0) or 0.0)
                    if saldo_ini > 0 and saldo_obj <= 0:
                        cap_obj["saldo_usdt"] = saldo_ini
                    cap_obj["valor_trade"] = float(SECRETS.get("futures_entry_usdt", 10.0) or 10.0)
                    payload["capital"] = cap_obj
                except Exception:
                    pass
            except Exception:
                pass

            self._send_json(payload)
            return

        if path == "/":
            if DASHBOARD_FILE.exists():
                self._send_html(DASHBOARD_FILE.read_text(encoding="utf-8"))
            else:
                self._send_html("<h1>dashboard_admin.html não encontrado</h1>", 404)
            return

        self._send_json({"error": "Endpoint nao encontrado"}, 404)

    def do_POST(self):
        try:
            body = self._read_json()
        except Exception as e:
            self._send_json({"ok": False, "error": f"JSON inválido: {e}"}, 400)
            return

        if self.path == "/api/bot-control":
            ativo = bool(body.get("ativo", True))
            with SECRETS_LOCK:
                SECRETS["bot_enabled_manual"] = ativo
                save_secrets(SECRETS)
            with STATE_LOCK:
                ESTADO_GLOBAL["bot_ativo"] = ativo
                ESTADO_GLOBAL["bot_status_label"] = "OPERANDO" if ativo else "DESLIGADO"
                ESTADO_GLOBAL["bot_pause_reason"] = "Bot operando normalmente" if ativo else "Bot desligado manualmente"
            log.info("Bot %s pelo painel", "LIGADO" if ativo else "DESLIGADO")
            self._send_json({
                "ok": True,
                "bot_ativo": ativo,
                "bot_status_label": ESTADO_GLOBAL.get("bot_status_label", "OPERANDO"),
                "bot_pause_reason": ESTADO_GLOBAL.get("bot_pause_reason", ""),
            })
            return

        if self.path == "/api/pares":
            pares = body.get("pares", [])
            if not isinstance(pares, list):
                pares = []
            with STATE_LOCK:
                ESTADO_GLOBAL["pares_ativos"] = pares
            log.info("Pares atualizados: %s", pares)
            self._send_json({"ok": True})
            return

        if self.path == "/api/config":
            try:
                with SECRETS_LOCK:
                    if "binance_key" in body:
                        SECRETS["binance_api_key"] = str(body.get("binance_key", "") or "")
                    if "binance_secret" in body:
                        SECRETS["binance_api_secret"] = str(body.get("binance_secret", "") or "")
                    if "alpha_key" in body:
                        SECRETS["alpha_vantage_api_key"] = str(body.get("alpha_key", "") or "")
                    if "finnhub_key" in body:
                        SECRETS["finnhub_api_key"] = str(body.get("finnhub_key", "") or "")
                    if "newsapi_key" in body:
                        SECRETS["newsapi_api_key"] = str(body.get("newsapi_key", "") or "")
                    if "openai_key" in body:
                        SECRETS["openai_api_key"] = str(body.get("openai_key", "") or "")
                    if "openai_model" in body:
                        SECRETS["openai_model"] = str(body.get("openai_model", "gpt-5.4") or "gpt-5.4")
                    if "openai_enabled" in body:
                        SECRETS["openai_enabled"] = _to_bool(body.get("openai_enabled", False))
                    if "sniper_mode" in body:
                        SECRETS["sniper_mode"] = str(body.get("sniper_mode", "off") or "off").lower()
                    if "capital_total" in body:
                        SECRETS["capital_total"] = float(body.get("capital_total", 100) or 100)
                    if "daily_loss_limit" in body:
                        SECRETS["daily_loss_limit"] = float(body.get("daily_loss_limit", 50) or 50)
                    if "trading_preset" in body:
                        SECRETS["trading_preset"] = str(body.get("trading_preset", "equilibrado") or "equilibrado").lower()

                    if "trading_mode" in body:
                        SECRETS["trading_mode"] = str(body.get("trading_mode", "spot") or "spot").lower()

                    if "futures_leverage" in body:
                        try:
                            SECRETS["futures_leverage"] = max(1, int(body.get("futures_leverage", 1) or 1))
                        except Exception:
                            SECRETS["futures_leverage"] = 1

                    if "futures_allow_short" in body:
                        v = body.get("futures_allow_short", False)
                        if isinstance(v, str):
                            v = v.strip().lower() in ("1", "true", "yes", "on", "sim")
                        SECRETS["futures_allow_short"] = _to_bool(v)

                    if "futures_margin_type" in body:
                        mt = str(body.get("futures_margin_type", "ISOLATED") or "ISOLATED").upper()
                        if mt not in ("ISOLATED", "CROSSED", "CROSS"):
                            mt = "ISOLATED"
                        if mt == "CROSS":
                            mt = "CROSSED"
                        SECRETS["futures_margin_type"] = mt
                    if "futures_entry_usdt" in body:
                        try:
                            SECRETS["futures_entry_usdt"] = max(1.0, float(body.get("futures_entry_usdt", 10.0) or 10.0))
                        except Exception:
                            SECRETS["futures_entry_usdt"] = 10.0

                    save_secrets(dict(SECRETS))
                    from .config import load_secrets
                    saved = load_secrets()
                    SECRETS.clear()
                    SECRETS.update(saved)

                with STATE_LOCK:
                    ESTADO_GLOBAL["capital_inicial"] = float(SECRETS.get("capital_total", 100.0))
                    ESTADO_GLOBAL["daily_loss_limit"] = float(SECRETS.get("daily_loss_limit", 50.0))

                self._send_json({
                    "ok": True,
                    "saved": True,
                    "config": {
                        "binance_api_key": SECRETS.get("binance_api_key", ""),
                        "binance_api_secret": SECRETS.get("binance_api_secret", ""),
                        "alpha_vantage_api_key": SECRETS.get("alpha_vantage_api_key", ""),
                        "finnhub_api_key": SECRETS.get("finnhub_api_key", ""),
                        "newsapi_api_key": SECRETS.get("newsapi_api_key", ""),
                        "openai_api_key": SECRETS.get("openai_api_key", ""),
                        "openai_model": SECRETS.get("openai_model", "gpt-5.4"),
                        "openai_enabled": bool(SECRETS.get("openai_enabled", False)),
                        "capital_total": float(SECRETS.get("capital_total", 100.0)),
                        "daily_loss_limit": float(SECRETS.get("daily_loss_limit", 50.0)),
                        "trading_preset": str(SECRETS.get("trading_preset", "equilibrado")).lower(),
                        "trading_mode": str(SECRETS.get("trading_mode", "spot")).lower(),
                        "futures_leverage": int(SECRETS.get("futures_leverage", 1) or 1),
                        "futures_allow_short": bool(SECRETS.get("futures_allow_short", False)),
                        "futures_margin_type": str(SECRETS.get("futures_margin_type", "ISOLATED")).upper(),
                        "sniper_mode": str(SECRETS.get("sniper_mode", "off")).lower(),
                        "futures_entry_usdt": float(SECRETS.get("futures_entry_usdt", 10.0) or 10.0)
                    }
                })
            except Exception as e:
                self._send_json({"ok": False, "error": str(e)}, 500)
            return
        if self.path == "/api/reset":
            self._send_json({"ok": True})
            return

        self._send_json({"error": "Endpoint nao encontrado"}, 404)

    def log_message(self, *args):
        return


def iniciar_dashboard():
    port = get_port()
    server = ThreadingHTTPServer(("0.0.0.0", port), DashboardHandler)
    log.info("🌐 Dashboard rodando na porta %s", port)
    server.serve_forever()

