import pandas as pd


class FlowProxyDetector:
    def __init__(self):
        self.alertas = []
        self.last_by_pair = {}

    @staticmethod
    def _safe_float(v, default=0.0):
        try:
            return float(v)
        except Exception:
            return default

    def analisar_fluxo(self, par: str, df: pd.DataFrame):
        if df is None or len(df) < 25:
            out = {
                "pair": par,
                "label": "FLOW_NEUTRO",
                "score": 0.0,
                "volume_ratio": 1.0,
                "body_strength": 0.0,
                "wick_bias": 0.0,
                "close_pos": 0.5,
                "range_ratio": 1.0,
                "flow_state": "insuficiente",
                "motivo": "Dados insuficientes",
            }
            self.last_by_pair[par] = out
            return out

        d = df.copy()
        for c in ["open", "high", "low", "close", "volume"]:
            d[c] = d[c].astype(float)

        last = d.iloc[-1]
        prev = d.iloc[-20:-1]

        o = self._safe_float(last["open"])
        h = self._safe_float(last["high"])
        l = self._safe_float(last["low"])
        c = self._safe_float(last["close"])
        v = self._safe_float(last["volume"])

        candle_range = max(h - l, 1e-9)
        body = abs(c - o)
        upper_wick = max(h - max(c, o), 0.0)
        lower_wick = max(min(c, o) - l, 0.0)
        avg_vol = max(prev["volume"].mean(), 1e-9)
        avg_range = max((prev["high"] - prev["low"]).mean(), 1e-9)

        volume_ratio = v / avg_vol
        range_ratio = candle_range / avg_range
        body_strength = body / candle_range
        close_pos = (c - l) / candle_range
        wick_bias = (lower_wick - upper_wick) / candle_range

        ema21 = d["close"].ewm(span=21, adjust=False).mean().iloc[-1]
        above_ema = c > ema21
        below_ema = c < ema21

        label = "FLOW_NEUTRO"
        flow_state = "neutro"
        motivo = "Fluxo neutro"
        score = 0.0

        if volume_ratio >= 1.40 and range_ratio >= 1.00 and body_strength >= 0.45 and close_pos >= 0.63 and above_ema:
            label = "FLOW_BULL_FORTE"
            flow_state = "agressao_compradora"
            score = min(1.0, 0.32 + (volume_ratio - 1.40) * 0.18 + (body_strength - 0.45) * 0.55)
            motivo = f"Impulso comprador | vol {volume_ratio:.2f}x | body {body_strength:.2f}"
        elif volume_ratio >= 1.40 and range_ratio >= 1.00 and body_strength >= 0.45 and close_pos <= 0.37 and below_ema:
            label = "FLOW_BEAR_FORTE"
            flow_state = "agressao_vendedora"
            score = -min(1.0, 0.32 + (volume_ratio - 1.40) * 0.18 + (body_strength - 0.45) * 0.55)
            motivo = f"Impulso vendedor | vol {volume_ratio:.2f}x | body {body_strength:.2f}"
        elif volume_ratio >= 1.45 and body_strength <= 0.36 and range_ratio >= 0.80:
            label = "FLOW_ABSORCAO"
            flow_state = "absorcao"
            score = 0.0
            motivo = f"Absorção possível | vol {volume_ratio:.2f}x | body {body_strength:.2f}"
        elif volume_ratio >= 1.12 and lower_wick >= candle_range * 0.30 and close_pos >= 0.52:
            label = "FLOW_REJEICAO_BULL"
            flow_state = "rejeicao_compradora"
            score = min(0.75, 0.18 + (volume_ratio - 1.12) * 0.18)
            motivo = f"Rejeição compradora | pavio inferior | vol {volume_ratio:.2f}x"
        elif volume_ratio >= 1.12 and upper_wick >= candle_range * 0.30 and close_pos <= 0.48:
            label = "FLOW_REJEICAO_BEAR"
            flow_state = "rejeicao_vendedora"
            score = -min(0.75, 0.18 + (volume_ratio - 1.12) * 0.18)
            motivo = f"Rejeição vendedora | pavio superior | vol {volume_ratio:.2f}x"
        elif volume_ratio >= 1.20 and range_ratio >= 0.95 and body_strength >= 0.40:
            flow_state = "quase_fluxo"
            motivo = f"Quase fluxo | vol {volume_ratio:.2f}x | range {range_ratio:.2f}x | body {body_strength:.2f}"
        elif volume_ratio >= 1.05 and max(lower_wick, upper_wick) >= candle_range * 0.26:
            flow_state = "quase_rejeicao"
            side = "compradora" if lower_wick >= upper_wick else "vendedora"
            motivo = f"Quase rejeição {side} | vol {volume_ratio:.2f}x"

        out = {
            "pair": par,
            "label": label,
            "score": round(float(score), 4),
            "volume_ratio": round(float(volume_ratio), 4),
            "body_strength": round(float(body_strength), 4),
            "wick_bias": round(float(wick_bias), 4),
            "close_pos": round(float(close_pos), 4),
            "range_ratio": round(float(range_ratio), 4),
            "flow_state": flow_state,
            "motivo": motivo,
        }

        self.last_by_pair[par] = out
        if label != "FLOW_NEUTRO":
            self.alertas.append(out)
            self.alertas = self.alertas[-30:]
        return out

    def ajustar_sinal(self, sinal: str, par: str, df: pd.DataFrame):
        sinal = (sinal or "AGUARDAR").upper()
        info = self.analisar_fluxo(par, df)
        label = info["label"]
        score = info["score"]
        if sinal == "COMPRAR" and label in ("FLOW_BEAR_FORTE", "FLOW_REJEICAO_BEAR"):
            return "AGUARDAR", score
        if sinal == "VENDER" and label in ("FLOW_BULL_FORTE", "FLOW_REJEICAO_BULL"):
            return "AGUARDAR", score
        return sinal, score

