from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List


class TradeJournal:
    def __init__(self, path: str = "data/trades_journal.jsonl"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append_trade(self, trade: Dict[str, Any]) -> None:
        row = dict(trade or {})
        row.setdefault("ts_utc", datetime.now(timezone.utc).isoformat())
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    def read_all(self, limit: int | None = None) -> List[Dict[str, Any]]:
        if not self.path.exists():
            return []
        rows: List[Dict[str, Any]] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
        if limit is not None and limit > 0:
            rows = rows[-limit:]
        return rows

    def recent_for_pair(self, par: str, limit: int = 30) -> List[Dict[str, Any]]:
        par = str(par or "").upper()
        rows = [x for x in self.read_all() if str(x.get("par", "")).upper() == par]
        return rows[-limit:]


def classify_trade_outcome(trade: Dict[str, Any]) -> str:
    pnl = float(trade.get("pnl_liquido", 0.0) or 0.0)
    motivo_saida = str(trade.get("motivo_saida", "") or "").lower()
    news_conflict = bool(trade.get("news_conflict", False))
    flow_label = str(trade.get("flow_label", "") or "").lower()
    regime = str(trade.get("regime", "") or "").lower()
    score = float(trade.get("score", 0.0) or 0.0)
    atr_ratio = float(trade.get("atr_ratio", 0.0) or 0.0)

    if pnl > 0:
        if "take" in motivo_saida or "alvo" in motivo_saida:
            return "acerto_take"
        if "gest" in motivo_saida or "ia" in motivo_saida:
            return "acerto_gestao"
        return "acerto_geral"

    if news_conflict:
        return "erro_noticia_contraria"
    if "absorcao" in flow_label and pnl < 0:
        return "erro_flow_absorcao_contraria"
    if "stop" in motivo_saida and atr_ratio > 1.2:
        return "erro_stop_curto"
    if regime in ("range", "lateral", "chop"):
        return "erro_mercado_lateral"
    if abs(score) < 6:
        return "erro_score_fraco"
    if "ia" in motivo_saida:
        return "erro_gestao_ia"
    return "erro_geral"
