import json
from pathlib import Path

def get_valor_trade(default=10):
    try:
        p = Path("/tmp/fund_state.json")
        if p.exists():
            data = json.loads(p.read_text())
            return float(data.get("valor_trade", default))
    except:
        pass
    return default
