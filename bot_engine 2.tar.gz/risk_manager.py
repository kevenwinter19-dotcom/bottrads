def calcular_valor_trade(saldo_usdt, risco_percent=0.05, min_trade=10):
    try:
        valor = saldo_usdt * risco_percent

        # respeita mínimo
        if valor < min_trade:
            valor = min_trade

        return round(valor, 2)
    except:
        return min_trade
