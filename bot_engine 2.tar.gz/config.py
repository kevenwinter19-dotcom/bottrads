import json
from pathlib import Path
from threading import RLock

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"
TEMPLATES_DIR = BASE_DIR / "templates"

DATA_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)

SECRETS_PATH = BASE_DIR / "secrets.json"
MEMORY_PATH = DATA_DIR / "memoria_v4.json"

DEFAULT_SECRETS = {
    "trading_mode": "spot",
    "futures_leverage": 1,
    "futures_allow_short": False,
    "futures_margin_type": "ISOLATED",
    "futures_entry_usdt": 10.0,
    "binance_api_key": "",
    "binance_api_secret": "",
    "usar_testnet": True,
    "capital_total": 100.0,
    "daily_loss_limit": 50.0,
    "max_trades_day": 12,
    "max_losses_seguidos": 3,
    "min_winrate_trades": 6,
    "min_winrate_pct": 35.0,
    "port": 8080,
    "panel_password": "admin123",
    "bot_enabled_manual": True,
    "alpha_vantage_api_key": "",
    "finnhub_api_key": "",
    "newsapi_api_key": "",
    "openai_api_key": "",
    "openai_model": "gpt-5.4",
    "openai_enabled": False,
    "openai_reasoning_effort": "medium",
    "ai_provider": "openai",
    "ai_min_confidence": 0.60,
    "trading_preset": "equilibrado",
    "risk_per_trade_conservador": 0.008,
    "risk_per_trade_equilibrado": 0.012,
    "risk_per_trade_agressivo": 0.015,
    "break_even_trigger_rr": 1.0,
    "trailing_trigger_rr": 1.4,
    "trailing_offset_rr": 0.65,
}

SECRETS_LOCK = RLock()
STATE_LOCK = RLock()
SESSION_LOCK = RLock()


def save_secrets(data: dict) -> None:
    merged = DEFAULT_SECRETS.copy()
    merged.update(data or {})
    with SECRETS_PATH.open("w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2, ensure_ascii=False)


def load_secrets() -> dict:
    if not SECRETS_PATH.exists():
        save_secrets(DEFAULT_SECRETS.copy())
        return DEFAULT_SECRETS.copy()
    try:
        with SECRETS_PATH.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {}
    merged = DEFAULT_SECRETS.copy()
    merged.update(data)
    return merged


SECRETS = load_secrets()

PARES_PADRAO = ["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "ADAUSDT"]
RISCO_BASE = 0.02
MAX_POSICOES = 2
MAX_DRAWDOWN = 0.15
INTERVALO = 60


def get_port() -> int:
    return int(SECRETS.get("port", DEFAULT_SECRETS["port"]))


def get_capital_total() -> float:
    return float(SECRETS.get("capital_total", DEFAULT_SECRETS["capital_total"]))


def get_testnet() -> bool:
    return bool(SECRETS.get("usar_testnet", DEFAULT_SECRETS["usar_testnet"]))

