from __future__ import annotations

from typing import Any, Dict, List


def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default


def _clip(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


class WhaleRealDetector:
    """
    Detector compatível com o engine atual.
    Interface esperada:
      - WhaleRealDetector()
      - .analisar(client, par, df_m15, preco)
      - .alertas
      - .last_by_pair
    """
    def __init__(self) -> None:
        self.alertas: List[Dict[str, Any]] = []
        self.last_by_pair: Dict[str, Dict[str, Any]] = {}

    def _order_book(self, client: Any, par: str) -> Dict[str, Any]:
        try:
            return client.get_order_book(symbol=par, limit=10) or {"bids": [], "asks": []}
        except Exception:
            return {"bids": [], "asks": []}

    def _agg_trades(self, client: Any, par: str) -> List[Dict[str, Any]]:
        # compatível com spot client
        try:
            return client.get_aggregate_trades(symbol=par, limit=200) or []
        except Exception:
            return []

    def _book_imbalance(self, order_book: Dict[str, Any]) -> float:
        bids = order_book.get("bids") or []
        asks = order_book.get("asks") or []
        bid_vol = 0.0
        ask_vol = 0.0
        for x in bids[:10]:
            try:
                bid_vol += float(x[1])
            except Exception:
                pass
        for x in asks[:10]:
            try:
                ask_vol += float(x[1])
            except Exception:
                pass
        total = bid_vol + ask_vol
        if total <= 0:
            return 0.0
        return _clip((bid_vol - ask_vol) / total, -1.0, 1.0)

    def _delta_ratio(self, trades: List[Dict[str, Any]]) -> tuple[float, float]:
        buy_notional = 0.0
        sell_notional = 0.0
        for t in trades[-200:]:
            price = _safe_float(t.get("p") or t.get("price"))
            qty = _safe_float(t.get("q") or t.get("qty") or t.get("quantity"))
            maker = t.get("m")
            notion = price * qty
            # m=True => buyer is maker => agressão vendedora
            if maker is True:
                sell_notional += notion
            elif maker is False:
                buy_notional += notion
        total = buy_notional + sell_notional
        if total <= 0:
            return 0.0, 0.0
        return _clip((buy_notional - sell_notional) / total, -1.0, 1.0), total

    def analisar(self, client: Any, par: str, df_m15: Any, preco: float) -> Dict[str, Any]:
        order_book = self._order_book(client, par)
        trades = self._agg_trades(client, par)

        book_imbalance = self._book_imbalance(order_book)
        delta_ratio, trade_notional = self._delta_ratio(trades)

        price_change_pct = 0.0
        atr_ratio = 1.0
        try:
            if hasattr(df_m15, "iloc") and len(df_m15) >= 2:
                prev_close = float(df_m15.iloc[-2]["close"])
                if prev_close > 0:
                    price_change_pct = (float(preco) - prev_close) / prev_close
                atr = float(df_m15.iloc[-1].get("atr", 0) if hasattr(df_m15.iloc[-1], "get") else df_m15.iloc[-1]["atr"])
                if prev_close > 0 and atr > 0:
                    atr_ratio = atr / prev_close * 100.0
        except Exception:
            pass

        # score composto simples e robusto
        score = (
            delta_ratio * 0.55
            + book_imbalance * 0.35
            + _clip(price_change_pct * 20.0, -1.0, 1.0) * 0.10
        )
        score = _clip(score, -1.0, 1.0)

        label = "WHALE_NEUTRO"
        flow_state = "neutro"

        if score >= 0.55 and delta_ratio > 0.20 and book_imbalance > 0.10:
            label = "INITIATIVE_BUY"
            flow_state = "agressao_real_compradora"
        elif score <= -0.55 and delta_ratio < -0.20 and book_imbalance < -0.10:
            label = "INITIATIVE_SELL"
            flow_state = "agressao_real_vendedora"
        elif delta_ratio > 0.20 and book_imbalance < -0.05 and price_change_pct >= 0:
            label = "ABSORPTION_BUY"
            flow_state = "absorcao_compradora"
        elif delta_ratio < -0.20 and book_imbalance > 0.05 and price_change_pct <= 0:
            label = "ABSORPTION_SELL"
            flow_state = "absorcao_vendedora"

        out = {
            "label": label,
            "score": round(score, 4),
            "delta_ratio": round(delta_ratio, 4),
            "book_imbalance": round(book_imbalance, 4),
            "oi_change": 0.0,
            "funding_rate": 0.0,
            "liq_proxy": 0.0,
            "price_change_pct": round(price_change_pct * 100.0, 4),
            "trade_notional": round(trade_notional, 2),
            "flow_state": flow_state,
            "atr_ratio": round(atr_ratio, 4),
            "motivo": f"delta {delta_ratio:.2f} | book {book_imbalance:.2f} | price {price_change_pct*100:.2f}% | notional {trade_notional:.0f}",
        }

        self.last_by_pair[par] = out

        if label != "WHALE_NEUTRO":
            alert = {"pair": par, **out}
            self.alertas.append(alert)
            self.alertas = self.alertas[-30:]

        return out


# alias extra, caso algo antigo espere este nome
WhaleRealEngine = WhaleRealDetector
