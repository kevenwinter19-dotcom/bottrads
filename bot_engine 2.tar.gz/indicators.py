"""
indicators.py — MELHORADO v4.1
"""
from __future__ import annotations

import pandas as pd
from datetime import datetime, timezone
from binance.client import Client

TIMEFRAMES = {
    "M5": Client.KLINE_INTERVAL_5MINUTE,
    "M15": Client.KLINE_INTERVAL_15MINUTE,
    "H1": Client.KLINE_INTERVAL_1HOUR,
}


def sessao_mercado() -> str:
    h = datetime.now(timezone.utc).hour
    if 22 <= h or h < 7:
        return "ASIA"
    if 7 <= h < 12:
        return "LONDON"
    if 12 <= h < 16:
        return "OVERLAP"
    return "NY"


SESSAO_MULT = {
    "ASIA": 0.80,
    "LONDON": 1.10,
    "OVERLAP": 1.20,
    "NY": 1.00,
}


def calcular_indicadores(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    c = df["close"]
    h = df["high"]
    l = df["low"]

    df["ema9"] = c.ewm(span=9, adjust=False).mean()
    df["ema21"] = c.ewm(span=21, adjust=False).mean()
    df["ema50"] = c.ewm(span=50, adjust=False).mean()

    delta = c.diff()
    g = delta.clip(lower=0).ewm(com=13, adjust=False).mean()
    p = (-delta.clip(upper=0)).ewm(com=13, adjust=False).mean()
    df["rsi"] = 100 - (100 / (1 + g / p))

    ema12 = c.ewm(span=12, adjust=False).mean()
    ema26 = c.ewm(span=26, adjust=False).mean()
    df["macd"] = ema12 - ema26
    df["macd_signal"] = df["macd"].ewm(span=9, adjust=False).mean()
    df["macd_hist"] = df["macd"] - df["macd_signal"]

    sma20 = c.rolling(20).mean()
    std20 = c.rolling(20).std()
    df["bb_upper"] = sma20 + 2 * std20
    df["bb_lower"] = sma20 - 2 * std20
    df["bb_width"] = (df["bb_upper"] - df["bb_lower"]) / sma20.replace(0, 1)

    tr = pd.concat(
        [
            h - l,
            (h - c.shift()).abs(),
            (l - c.shift()).abs(),
        ],
        axis=1,
    ).max(axis=1)
    df["atr"] = tr.ewm(span=14, adjust=False).mean()
    df["atr_pct"] = df["atr"] / c.replace(0, 1)

    pt = (h + l + c) / 3
    if "time" in df.columns:
        try:
            df["_date"] = pd.to_datetime(df["time"]).dt.date
            pv = pt * df["volume"]
            df["vwap"] = pv.groupby(df["_date"].values).cumsum() / df["volume"].groupby(
                df["_date"].values
            ).cumsum()
            df.drop(columns=["_date"], inplace=True)
        except Exception:
            df["vwap"] = (pt * df["volume"]).cumsum() / df["volume"].cumsum()
    else:
        df["vwap"] = (pt * df["volume"]).cumsum() / df["volume"].cumsum()

    df["vol_ma20"] = df["volume"].rolling(20).mean()
    df["vol_ratio"] = df["volume"] / df["vol_ma20"].replace(0, 1)

    df["sr_high"] = h.rolling(20).max()
    df["sr_low"] = l.rolling(20).min()

    rsi_min = df["rsi"].rolling(14).min()
    rsi_max = df["rsi"].rolling(14).max()
    rsi_range = (rsi_max - rsi_min).replace(0, 1)
    df["stoch_rsi"] = ((df["rsi"] - rsi_min) / rsi_range) * 100

    return df.dropna().reset_index(drop=True)


def score_tf(df: pd.DataFrame, par: str = ""):
    if len(df) < 3:
        return 0, df.iloc[-1] if len(df) > 0 else None

    u = df.iloc[-1]
    p1 = df.iloc[-2]
    p2 = df.iloc[-3]
    s = 0.0

    if u["ema9"] > u["ema21"] > u["ema50"]:
        s += 3.0
    elif u["ema9"] < u["ema21"] < u["ema50"]:
        s -= 3.0
    elif u["ema9"] > u["ema21"]:
        s += 1.5
    elif u["ema9"] < u["ema21"]:
        s -= 1.5

    if p1["ema9"] <= p1["ema21"] and u["ema9"] > u["ema21"]:
        s += 2.0
    elif p1["ema9"] >= p1["ema21"] and u["ema9"] < u["ema21"]:
        s -= 2.0

    atr_pct = float(u.get("atr_pct", 0.005))
    rsi_peso = 2.5 if atr_pct > 0.01 else 1.5
    rsi = float(u["rsi"])

    if rsi < 30:
        s += rsi_peso
    elif rsi > 70:
        s -= rsi_peso
    elif rsi < 45:
        s += rsi_peso * 0.5
    elif rsi > 55:
        s -= rsi_peso * 0.5


    stoch = float(u.get("stoch_rsi", 50))
    if stoch < 20 and rsi < 40:
        s += 1.5
    elif stoch > 80 and rsi > 60:
        s -= 1.5


    if p1["macd_hist"] <= 0 and u["macd_hist"] > 0:
        s += 2.0
    elif p1["macd_hist"] >= 0 and u["macd_hist"] < 0:
        s -= 2.0

    if u["macd_hist"] > p1["macd_hist"] > p2["macd_hist"] and u["macd_hist"] > 0:
        s += 0.5
    elif u["macd_hist"] < p1["macd_hist"] < p2["macd_hist"] and u["macd_hist"] < 0:
        s -= 0.5

    if float(u["close"]) > float(u["vwap"]):
        s += 1.0
    else:
        s -= 1.0

    bb_range = float(u["bb_upper"]) - float(u["bb_lower"])
    if bb_range > 0:
        bb_pos = (float(u["close"]) - float(u["bb_lower"])) / bb_range
        if bb_pos < 0.15:
            s += 1.0
        elif bb_pos > 0.85:
            s -= 1.0


    bb_w = float(u.get("bb_width", 0.1))
    if bb_w < 0.02:
        s *= 0.6

    vol_ratio = float(u.get("vol_ratio", 1.0))
    if vol_ratio > 1.8:
        s *= 1.25
    elif vol_ratio < 0.5:
        s *= 0.75

    sr_high = float(u.get("sr_high", float(u["close"]) * 1.05))
    sr_low = float(u.get("sr_low", float(u["close"]) * 0.95))
    close = float(u["close"])

    if close > 0:
        dist_r = (sr_high - close) / close
        dist_s = (close - sr_low) / close
        if s > 0 and dist_r < 0.003:
            s *= 0.5
        if s < 0 and dist_s < 0.003:
            s *= 0.5


    return round(s, 2), u


def sinal_multi_tf(client, par: str):
    scores = {}
    ultimo_m15 = None
    sessao = sessao_mercado()
    sess_mult = SESSAO_MULT.get(sessao, 1.0)

    for nome, tf in TIMEFRAMES.items():
        try:
            klines = client.get_klines(symbol=par, interval=tf, limit=150)
            df = pd.DataFrame(
                klines,
                columns=[
                    "time",
                    "open",
                    "high",
                    "low",
                    "close",
                    "volume",
                    "close_time",
                    "quote_vol",
                    "trades",
                    "taker_base",
                    "taker_quote",
                    "ignore",
                ],
            )
            for col in ["open", "high", "low", "close", "volume"]:
                df[col] = df[col].astype(float)
            df["time"] = pd.to_datetime(df["time"], unit="ms")
            df = calcular_indicadores(df)
            s, u = score_tf(df, par=par)
            scores[nome] = {"score": s, "u": u, "df": df}
            if nome == "M15":
                ultimo_m15 = u
        except Exception:
            scores[nome] = {"score": 0, "u": None, "df": None}

    s_h1 = scores["H1"]["score"]
    s_m15 = scores["M15"]["score"]
    s_m5 = scores["M5"]["score"]

    mesma_direcao = (s_h1 > 0 and s_m15 > 0) or (s_h1 < 0 and s_m15 < 0)

    if mesma_direcao:
        score_total = (s_h1 * 2.5) + (s_m15 * 1.5) + (s_m5 * 1.0)
        threshold = 8.0
    else:
        score_total = (s_h1 * 1.5) + (s_m15 * 1.0) + (s_m5 * 0.5)
        threshold = 10.0

    score_total = round(score_total * sess_mult, 2)

    sinais_tf = {
        nome: (
            "COMPRAR" if d["score"] >= 4 else ("VENDER" if d["score"] <= -4 else "AGUARDAR")
        )
        for nome, d in scores.items()
    }

    if score_total >= threshold:
        sinal = "COMPRAR"
    elif score_total <= -threshold:
        sinal = "VENDER"
    else:
        sinal = "AGUARDAR"

    atr = float(ultimo_m15["atr"]) if ultimo_m15 is not None else 0.0
    preco = float(ultimo_m15["close"]) if ultimo_m15 is not None else 0.0
    df_m15 = scores["M15"]["df"]

    sr_high = float(ultimo_m15["sr_high"]) if ultimo_m15 is not None else 0.0
    sr_low = float(ultimo_m15["sr_low"]) if ultimo_m15 is not None else 0.0
    vol_ratio = float(ultimo_m15["vol_ratio"]) if ultimo_m15 is not None else 1.0
    stoch_rsi = float(ultimo_m15["stoch_rsi"]) if ultimo_m15 is not None else 50.0

    contexto_extra = {
        "sessao_mercado": sessao,
        "sess_mult": sess_mult,
        "score_h1": s_h1,
        "score_m15": s_m15,
        "score_m5": s_m5,
        "h1_m15_alinhados": mesma_direcao,
        "threshold_entrada": threshold,
        "resistencia_20p": round(sr_high, 6),
        "suporte_20p": round(sr_low, 6),
        "dist_resistencia_pct": round((sr_high - preco) / preco * 100, 3) if preco > 0 else 0,
        "dist_suporte_pct": round((preco - sr_low) / preco * 100, 3) if preco > 0 else 0,
        "volume_ratio": round(vol_ratio, 2),
        "stoch_rsi": round(stoch_rsi, 1),
        "bb_width": round(float(ultimo_m15.get("bb_width", 0)), 4) if ultimo_m15 is not None else 0,
    }

    return sinal, score_total, sinais_tf, atr, preco, df_m15, contexto_extra
