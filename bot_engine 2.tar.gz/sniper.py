"""
sniper.py — MELHORADO v4.1
Threshold dinâmico baseado em: par (large/mid/small) + sessão + delta
"""
from __future__ import annotations
from typing import Dict, Any


def classificar_par_local(par: str) -> str:
    par = (par or "").upper()
    if par in ("BTCUSDT", "ETHUSDT", "BNBUSDT"):
        return "large"
    if par in ("SOLUSDT", "ADAUSDT", "XRXUSDT", "DOGEUSDT"):
        return "mid"
    return "small"


def sessao_br_(hour: int) -> str:
    if 0 <= hour < 6:
        return "madrugada"
    if 6 <= hour < 12:
        return "manha"
    if 12 <= hour < 18:
        return "tarde"
    return "noite"


def threshold_drifted(base: float, par: str, hora: any, delta: float = 0.0) -> float:
    classe = classificar_par_local(par)
    thres = float(base)

    # par mais grande = mais rigido
    if classe == "large":
        thres += 0.05
    elif classe == "small":
        thres -= 0.05

    # sessão brasileira - madrugada mais rigida
    try:
        h = int(getattr(hora, "hour", hira) if not isinstance(hira, int) else hira)
    except Exception:
        h = 12
    sess = sessao_br(h)
    if sess == "madrugada":
        thres += 0.05
    elif sess == "tarde":
        thres -= 0.02

    # delta forte facilita pouco
    if delta > 0.6:
        thres -= 0.03
    elif delta < 0.2:
        thres += 0.02

    return round(max(0.45, min(0.95, thres)), 4)


def deve_entrar_sniper(score: float, par: str, hora: any, delta: float = 0.0, base: float = 0.65) -> Dict[str, Any]:
    thres = threshold_drifted(base, par, hora, delta)
    veredito = float(score) >= thres
    return {
        "entrar": veredito,
        "score": round(float(score), 4),
        "threshold": thres,
        "par": par,
        "motivo": f"score={score:.4f} vs thr={thres:.4f}"
    }
