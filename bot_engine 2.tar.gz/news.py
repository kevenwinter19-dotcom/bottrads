from datetime import datetime, timezone
import requests
from .config import SECRETS, SECRETS_LOCK
from .logging_setup import log


class AlphaNewsManager:
    def __init__(self):
        self.items = []
        self.score = 0.0
        self.label = "Neutro"
        self.last_update = None
        self.fear_value = 50
        self.fear_label = "Neutro"

    def _pair_keywords(self, pair):
        pair = (pair or "").upper()
        mapping = {
            "BTCUSDT": ["bitcoin", "btc"],
            "ETHUSDT": ["ethereum", "eth"],
            "BNBUSDT": ["binance", "bnb", "binance coin"],
            "SOLUSDT": ["solana", "sol"],
            "ADAUSDT": ["cardano", "ada"],
        }
        return mapping.get(pair, [pair.replace("USDT", "").lower()])

    def _score_text(self, text):
        text = (text or "").lower()
        pos = {
            "surge": 0.22, "rally": 0.22, "gain": 0.12, "bull": 0.16, "bullish": 0.18,
            "approve": 0.18, "approval": 0.18, "etf": 0.15, "adoption": 0.18,
            "partnership": 0.18, "growth": 0.14, "record": 0.16, "buy": 0.10,
            "breakout": 0.18, "recovery": 0.14, "strong": 0.08, "expansion": 0.14,
            "institutional": 0.14, "inflow": 0.20,
        }
        neg = {
            "drop": -0.12, "crash": -0.24, "bear": -0.16, "bearish": -0.18, "hack": -0.28,
            "lawsuit": -0.22, "ban": -0.25, "fraud": -0.30, "selloff": -0.22,
            "decline": -0.12, "liquidation": -0.20, "dump": -0.20, "weak": -0.08,
            "down": -0.06, "outflow": -0.16, "fear": -0.10, "risk": -0.08,
            "crackdown": -0.24,
        }
        score = 0.0
        for w, v in pos.items():
            if w in text:
                score += v
        for w, v in neg.items():
            if w in text:
                score += v
        return max(-0.95, min(0.95, score))

    def _label(self, score):
        if score >= 0.35:
            return "Bullish"
        if score <= -0.35:
            return "Bearish"
        return "Neutral"

    def _fear_label(self, value):
        if value <= 24:
            return "Extreme Fear"
        if value <= 44:
            return "Fear"
        if value <= 55:
            return "Neutro"
        if value <= 74:
            return "Greed"
        return "Extreme Greed"

    def _make_item(self, pair, title, source, summary, published, score, image_url="", url=""):
        return {
            "pair": pair,
            "score": round(float(score), 4),
            "title": title or "Sem título",
            "source": source or "Sistema",
            "summary": (summary or "")[:260],
            "time_published": published or datetime.now().strftime("%Y%m%dT%H%M%S"),
            "overall_sentiment_label": self._label(score),
            "image_url": image_url or "",
            "url": url or "",
        }

    def _fetch_finnhub(self, pairs, api_key):
        out = []
        r = requests.get("https://finnhub.io/api/v1/news", params={"category": "crypto", "token": api_key}, timeout=8)
        data = r.json()
        if not isinstance(data, list):
            return []
        for pair in pairs[:5]:
            kws = self._pair_keywords(pair)
            hits = []
            for item in data[:120]:
                headline = str(item.get("headline") or "")
                summary = str(item.get("summary") or "")
                text = (headline + " " + summary).lower()
                if any(k in text for k in kws):
                    sc = self._score_text(text)
                    hits.append(self._make_item(
                        pair=pair,
                        title=headline,
                        source=item.get("source") or "Finnhub",
                        summary=summary,
                        published=str(item.get("datetime") or ""),
                        score=sc,
                        image_url=item.get("image") or "",
                        url=item.get("url") or "",
                    ))
            out.extend(hits[:4])
        return out

    def _fetch_newsapi(self, pairs, api_key):
        out = []
        url = "https://newsapi.org/v2/everything"
        for pair in pairs[:5]:
            query = " OR ".join(self._pair_keywords(pair))
            r = requests.get(url, params={
                "q": query,
                "language": "en",
                "sortBy": "publishedAt",
                "pageSize": 10,
                "apiKey": api_key,
            }, timeout=8)
            data = r.json()
            articles = data.get("articles") or []
            if not isinstance(articles, list):
                articles = []
            for a in articles[:4]:
                title = a.get("title") or ""
                summary = a.get("description") or ""
                text = f"{title} {summary}"
                sc = self._score_text(text)
                out.append(self._make_item(
                    pair=pair,
                    title=title,
                    source=(a.get("source") or {}).get("name") or "NewsAPI",
                    summary=summary,
                    published=a.get("publishedAt") or "",
                    score=sc,
                    image_url=a.get("urlToImage") or "",
                    url=a.get("url") or "",
                ))
        return out

    def _fetch_alpha(self, pairs, api_key):
        out = []
        for pair in pairs[:5]:
            try:
                r = requests.get(
                    "https://www.alphavantage.co/query",
                    params={"function": "NEWS_SENTIMENT", "limit": 50, "sort": "LATEST", "apikey": api_key},
                    timeout=8,
                )
                data = r.json()
                feed = data.get("feed") or []
                if not isinstance(feed, list):
                    feed = []
                kws = self._pair_keywords(pair)
                hits = []
                for item in feed[:40]:
                    title = item.get("title") or ""
                    summary = item.get("summary") or ""
                    text = (title + " " + summary).lower()
                    if any(k in text for k in kws):
                        sc = float(item.get("overall_sentiment_score") or 0.0)
                        hits.append(self._make_item(
                            pair=pair,
                            title=title,
                            source=item.get("source") or "Alpha Vantage",
                            summary=summary,
                            published=item.get("time_published") or "",
                            score=sc,
                            image_url="",
                            url=item.get("url") or "",
                        ))
                out.extend(hits[:4])
            except Exception as e:
                log.warning("⚠️ Alpha falhou para %s: %s", pair, e)
        return out

    def _dedupe(self, items):
        seen = set()
        out = []
        for item in items:
            key = ((item.get("title") or "").strip().lower(), (item.get("source") or "").strip().lower())
            if key in seen:
                continue
            seen.add(key)
            out.append(item)
        return out

    def _calc_fear_from_news(self, items):
        if not items:
            return 50, "Neutro"
        top = items[:8]
        media = sum(float(x.get("score") or 0) for x in top) / max(len(top), 1)
        valor = int(max(0, min(100, round(50 + media * 55))))
        return valor, self._fear_label(valor)

    def atualizar(self, pares):
        with SECRETS_LOCK:
            finnhub_key = SECRETS.get("finnhub_api_key", "")
            newsapi_key = SECRETS.get("newsapi_api_key", "")
            alpha_key = SECRETS.get("alpha_vantage_api_key", "")

        items = []
        fi = []
        ni = []
        ai = []
        try:
            if finnhub_key:
                fi = self._fetch_finnhub(pares, finnhub_key)
                items.extend(fi)
                log.info("📰 Finnhub: %s notícias", len(fi))
        except Exception as e:
            log.warning("⚠️ Finnhub falhou: %s", e)
        try:
            if newsapi_key:
                ni = self._fetch_newsapi(pares, newsapi_key)
                items.extend(ni)
                log.info("📰 NewsAPI: %s notícias", len(ni))
        except Exception as e:
            log.warning("⚠️ NewsAPI falhou: %s", e)
        try:
            if alpha_key:
                ai = self._fetch_alpha(pares, alpha_key)
                items.extend(ai)
                log.info("📰 Alpha: %s notícias", len(ai))
        except Exception as e:
            log.warning("⚠️ Alpha geral falhou: %s", e)

        bruto_total = len(items)
        items = self._dedupe(items)
        dedup_total = len(items)
        items.sort(key=lambda x: (abs(float(x.get("score") or 0)), x.get("time_published") or ""), reverse=True)

        if not items:
            now = datetime.now().strftime("%Y%m%dT%H%M%S")
            items = [
                self._make_item("BTCUSDT", "Mercado sem notícias relevantes no momento", "Sistema", "Nenhuma fonte retornou itens válidos neste ciclo.", now, 0),
                self._make_item("ETHUSDT", "Fluxo neutro de manchetes externas", "Sistema", "O bot segue monitorando novas manchetes.", now, 0),
                self._make_item("BNBUSDT", "Monitoramento ativo sem novos destaques", "Sistema", "Fallback local para evitar painel vazio.", now, 0),
            ]

        self.items = items[:12]
        total = sum(float(x.get("score") or 0) for x in self.items[:6])
        self.score = round(total, 4)
        if self.score >= 0.6:
            self.label = "Positivo"
        elif self.score <= -0.6:
            self.label = "Negativo"
        else:
            self.label = "Neutro"

        self.fear_value, self.fear_label = self._calc_fear_from_news(self.items)
        self.last_update = datetime.now(timezone.utc)
        log.info(
            "📰 News final: final=%s | bruto=%s | dedup=%s | Finnhub=%s | NewsAPI=%s | Alpha=%s | score=%s | %s | fear_news=%s (%s)",
            len(self.items), bruto_total, dedup_total, len(fi), len(ni), len(ai),
            self.score, self.label, self.fear_value, self.fear_label
        )

    def pair_bias(self, pair):
        rel = [x for x in self.items if x.get("pair") == pair]
        if not rel:
            return 0.0
        return round(sum(float(x.get("score") or 0) for x in rel[:3]), 4)

    def pair_snapshot(self, pair, desired_action=None):
        rel = [x for x in self.items if x.get("pair") == pair][:4]
        bias = round(sum(float(x.get("score") or 0.0) for x in rel), 4)
        abs_bias = abs(bias)
        if bias >= 0.35:
            direction = "bullish"
        elif bias <= -0.35:
            direction = "bearish"
        else:
            direction = "neutral"
        desired_action = (desired_action or "AGUARDAR").upper()
        conflicts = (desired_action == "COMPRAR" and bias <= -0.35) or (desired_action == "VENDER" and bias >= 0.35)
        return {
            "pair": pair,
            "bias": bias,
            "direction": direction,
            "strength": round(min(abs_bias, 1.0), 4),
            "conflicts_with_trade": conflicts,
            "headlines": [x.get("title") for x in rel[:2]],
            "top_sources": [x.get("source") for x in rel[:2]],
        }

