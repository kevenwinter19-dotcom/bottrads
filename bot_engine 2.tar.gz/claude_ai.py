from .ai_decider import OpenAIDecisionEngine


class ClaudeDecisionEngine(OpenAIDecisionEngine):
    """Compatibilidade com a base antiga.

    O motor legado chamado Claude agora usa OpenAI por baixo.
    """

    pass

