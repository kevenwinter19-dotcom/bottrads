from __future__ import annotations

import json
import time
from typing import Any, Dict

from .config import SECRETS, SECRETS_LOCK
from .logging_setup import log


SYSTEM_PROMPT = """
Você é um decisor tático de trade.
Responda somente JSON válido com:
acao, confianca, estrategia, motivo
""".strip()


class OpenAIDecisionEngine:
    """
    Compatível com imports antigos e novos.
    Métodos:
      - decidir(ctx)
      - decide(ctx)
    Atributos:
      - last_decision
      - provider_status
    """

    def __init__(self) -> None:
        self.last_decision: Dict[str, Any] = {}
        self.provider_status = "local"

    def decide(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        return self.decidir(ctx)

    def decidir(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        with SECRETS_LOCK:
            enabled = bool(SECRETS.get("openai_enabled", False))
            if enabled and self._should_skip_openai(ctx):
                out = self._local_fallback(ctx, "throttled")
                self.last_decision = out
                return out

            if enabled:
                self._mark_openai_call(ctx)

            api_key = str(SECRETS.get("openai_api_key", "") or "")
            model = str(SECRETS.get("openai_model", "gpt-5.4") or "gpt-5.4")

        if not enabled or not api_key:
            out = self._local_fallback(ctx, "disabled")
            self.last_decision = out
            self.provider_status = out.get("provider", "local")
            return out

        try:
            from openai import OpenAI  # type: ignore
            client = OpenAI(api_key=api_key)

            response = client.responses.create(
                model=model,
                input=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": json.dumps(ctx, ensure_ascii=False)},
                ],
                text={
                    "format": {
                        "type": "json_schema",
                        "name": "trade_decision",
                        "schema": {
                            "type": "object",
                            "properties": {
                                "acao": {"type": "string"},
                                "confianca": {"type": "number"},
                                "estrategia": {"type": "string"},
                                "motivo": {"type": "string"},
                            },
                            "required": ["acao", "confianca", "estrategia", "motivo"],
                            "additionalProperties": False,
                        },
                    }
                },
            )

            text = getattr(response, "output_text", "") or ""
            data = json.loads(text)
            out = {
                "acao": str(data.get("acao", "AGUARDAR")).upper(),
                "confianca": float(data.get("confianca", 0.0) or 0.0),
                "estrategia": str(data.get("estrategia", "contextual_multi_factor"))[:80],
                "motivo": str(data.get("motivo", "sem motivo"))[:180],
                "provider": "openai",
                "model": model,
            }
            if out["acao"] not in ("COMPRAR", "VENDER", "AGUARDAR"):
                out["acao"] = "AGUARDAR"

            self.last_decision = out
            self.provider_status = "openai"
            return out
        except Exception as e:
            log.error("OpenAI decision fallback: %s", e)
            out = self._local_fallback(ctx, "local_fallback")
            self.last_decision = out
            self.provider_status = out.get("provider", "local")
            return out


    def _ctx_pair(self, ctx: Dict[str, Any]) -> str:
        for k in ("pair", "par", "symbol", "ticker"):
            v = ctx.get(k)
            if v:
                return str(v)
        return ""

    def _ctx_score(self, ctx: Dict[str, Any]):
        for k in ("score", "score_total", "score_final", "score_rl", "score_ai", "confianca"):
            v = ctx.get(k)
            if isinstance(v, (int, float)):
                return float(v)
        return None

    def _ctx_reason(self, ctx: Dict[str, Any]) -> str:
        for k in ("motivo", "reason", "justificativa"):
            v = ctx.get(k)
            if v:
                return str(v).lower()
        return ""

    def _ctx_signal(self, ctx: Dict[str, Any]) -> str:
        for k in ("sinal", "acao", "signal", "action"):
            v = ctx.get(k)
            if v:
                return str(v).upper()
        return ""

    def _ctx_signature(self, ctx: Dict[str, Any]) -> str:
        keys = [
            "pair", "par", "symbol", "ticker",
            "score", "score_total", "score_final", "score_rl", "score_ai",
            "sinal", "acao", "signal", "action",
            "motivo", "reason",
            "preco", "price", "close", "entry",
        ]
        base = {}
        for k in keys:
            if k in ctx:
                base[k] = ctx.get(k)
        try:
            return json.dumps(base, sort_keys=True, default=str)
        except Exception:
            return str(base)

    def _should_skip_openai(self, ctx: Dict[str, Any]) -> bool:
        now = time.time()
        pair = self._ctx_pair(ctx)
        score = self._ctx_score(ctx)
        reason = self._ctx_reason(ctx)
        signal = self._ctx_signal(ctx)

        global_last = getattr(self, "_last_openai_global", 0.0)
        if now - global_last < 20:
            return True

        if signal in ("AGUARDAR", "HOLD", "WAIT", "NEUTRO"):
            return True

        blocked_tokens = (
            "minqty",
            "minnotional",
            "saldo bybit insuficiente",
            "spot usdt insuficiente",
            "posição futures já aberta",
            "posicao futures ja aberta",
            "notícia contradiz",
            "noticia contradiz",
            "symbol is not whitelisted",
            "permission denied",
        )
        if any(tok in reason for tok in blocked_tokens):
            return True

        if score is not None and abs(score) < 6:
            return True

        pair_calls = getattr(self, "_last_openai_pair_call", {})
        last_pair = pair_calls.get(pair, 0.0) if pair else 0.0
        if pair and now - last_pair < 180:
            return True

        sigs = getattr(self, "_last_openai_sig", {})
        sig = self._ctx_signature(ctx)
        if pair and sigs.get(pair) == sig and now - last_pair < 600:
            return True

        return False

    def _mark_openai_call(self, ctx: Dict[str, Any]) -> None:
        now = time.time()
        pair = self._ctx_pair(ctx)
        if not hasattr(self, "_last_openai_pair_call"):
            self._last_openai_pair_call = {}
        if not hasattr(self, "_last_openai_sig"):
            self._last_openai_sig = {}
        self._last_openai_global = now
        if pair:
            self._last_openai_pair_call[pair] = now
            self._last_openai_sig[pair] = self._ctx_signature(ctx)

    def _local_fallback(self, ctx: Dict[str, Any], provider: str) -> Dict[str, Any]:
        technical = ctx.get("technical") or {}
        flow_proxy = ctx.get("flow_proxy") or {}
        whale_real = ctx.get("whale_real") or {}
        news = ctx.get("news") or {}
        risk = ctx.get("risk") or ctx.get("risk_plan") or {}

        score = 0.0
        score += float(technical.get("score_total", technical.get("score", 0.0)) or 0.0) * 0.45
        score += float(flow_proxy.get("score", 0.0) or 0.0) * 0.20
        score += float(whale_real.get("score", 0.0) or 0.0) * 0.25
        score += float(news.get("score", 0.0) or 0.0) * 0.10

        acao = "AGUARDAR"
        if score >= 0.20 and risk:
            acao = "COMPRAR"
        elif score <= -0.20 and risk:
            acao = "VENDER"

        return {
            "acao": acao,
            "confianca": round(min(abs(score), 0.95), 4),
            "estrategia": "contextual_multi_factor",
            "motivo": f"fallback score {score:.3f}",
            "provider": provider,
            "model": "fallback",
        }


# aliases de compatibilidade
AIDecider = OpenAIDecisionEngine
