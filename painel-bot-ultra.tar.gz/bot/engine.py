from bot.fund_reader import get_valor_trade
import math
import time
from datetime import datetime, date
from typing import Dict, Tuple

import pandas as pd
import requests
from binance.client import Client
from binance.exceptions import BinanceAPIException
from .bybit_v5 import BybitV5

from .config import SECRETS, SECRETS_LOCK, INTERVALO, MAX_POSICOES, PARES_PADRAO, STATE_LOCK
from .state import ESTADO_GLOBAL
from .logging_setup import log
from .rl import AgenteQL
from .capital import GestaoCapital
from .nlp import AnalisadorNLP
from .news import AlphaNewsManager
from .flow_proxy import FlowProxyDetector
from .whale_real import WhaleRealDetector
from .optimizer import AutoOtimizador
from .indicators import sinal_multi_tf, calcular_indicadores
from .claude_ai import ClaudeDecisionEngine
from .market_context import calcular_contexto_mercado
from .risk_engine import RiskEngine


def classificar_fg(valor: int) -> str:
    if valor <= 24:
        return "Extreme Fear"
    if valor <= 44:
        return "Fear"
    if valor <= 55:
        return "Neutro"
    if valor <= 74:
        return "Greed"
    return "Extreme Greed"


def classificar_par(par: str) -> str:
    par = (par or "").upper()
    if par in ("BTCUSDT", "ETHUSDT", "BNBUSDT"):
        return "large"
    if par in ("SOLUSDT", "ADAUSDT", "XRPUSDT", "DOGEUSDT", "LINKUSDT", "AVAXUSDT"):
        return "mid"
    return "small"


def _perfil_risco_par(par: str, preset: str) -> Dict[str, float]:
    perfil_par = classificar_par(par)
    base = {
        "large": {"size_mult": 1.00},
        "mid": {"size_mult": 0.82},
        "small": {"size_mult": 0.60},
    }.get(perfil_par, {"size_mult": 0.82})
    if preset == "conservador":
        preset_mult = 0.82
    elif preset == "agressivo":
        preset_mult = 1.12
    else:
        preset_mult = 1.00
    return {"size_mult": round(base["size_mult"] * preset_mult, 4)}


def atualizar_estado(agente, gestao, sentimento, nlp, flow_proxy, whale_real, alpha_news, posicoes,
                     otimizador, log_buffer, pares_ativos, sinais_dashboard, resultado_dia,
                     trades_dia, wins_dia, losses_seguidos, ai_engine):
    with STATE_LOCK, SECRETS_LOCK:
        manual_enabled = bool(SECRETS.get("bot_enabled_manual", True))
        ESTADO_GLOBAL.update({
            "status": "rodando",
            "bot_ativo": manual_enabled,
            "capital": round(float(gestao.capital), 4),
            "capital_inicial": float(SECRETS.get("capital_total", 100.0)),
            "trades": agente.total_trades,
            "wins": agente.wins,
            "losses": agente.losses,
            "lucro_total": round(float(agente.lucro_total), 4),
            "resultado_dia": round(float(resultado_dia), 4),
            "trades_dia": trades_dia,
            "wins_dia": wins_dia,
            "losses_seguidos": losses_seguidos,
            "winrate_dia": round((wins_dia / trades_dia * 100.0), 2) if trades_dia > 0 else 0.0,
            "daily_loss_limit": float(SECRETS.get("daily_loss_limit", 50.0)),
            "daily_stop_hit": round(float(resultado_dia), 4) <= -float(SECRETS.get("daily_loss_limit", 50.0)),
            "sentimento": sentimento.valor,
            "fear_greed_label": sentimento.classificacao,
            "fear_alt": sentimento.raw_alt,
            "fear_alt_label": sentimento.classificacao_alt,
            "fear_news": sentimento.news,
            "fear_news_label": sentimento.classificacao_news,
            "nlp_score": nlp.score,
            "nlp_label": nlp.label,
            "nlp_total_noticias": getattr(nlp, "total_noticias", 0),
            "nlp_top_termos": getattr(nlp, "top_termos", []),
            "news_score": alpha_news.score,
            "news_label": alpha_news.label,
            "news_items": list(alpha_news.items),
            "flow_proxy_alertas": list(flow_proxy.alertas),
            "whale_real_alertas": list(whale_real.alertas),
            "whale_alertas": list(whale_real.alertas or flow_proxy.alertas),
            "posicoes": {k: dict(v) for k, v in posicoes.items()},
            "ultimo_sinal": sinais_dashboard if sinais_dashboard else ESTADO_GLOBAL.get("ultimo_sinal", {}),
            "historico_pnl": [],
            "parametros": {k: str(v) for k, v in otimizador.parametros.items()},
            "ultima_otimizacao": otimizador.ultima_otimizacao.strftime("%d/%m %H:%M") if otimizador.ultima_otimizacao else "Nunca",
            "log_recente": list(log_buffer)[-60:],
            "pares_ativos": list(pares_ativos),
            "heartbeat": datetime.now().isoformat(),
            "bot_pause_reason": ESTADO_GLOBAL.get("bot_pause_reason", ""),
            "bot_status_label": ESTADO_GLOBAL.get("bot_status_label", "OPERANDO"),
            "claude_last_decision": getattr(ai_engine, "last_decision", {}),
            "ai_last_decision": getattr(ai_engine, "last_decision", {}),
            "trading_preset": str(SECRETS.get("trading_preset", "equilibrado")).lower(),
        })


def ajustar_qtd_lote(client, par, qtd, preco, futures=False):
    try:
        exchange = str(SECRETS.get("exchange", "binance")).lower()
        bybit = None
        if exchange == "bybit":
            try:
                bybit = BybitV5(
                    api_key=SECRETS.get("bybit_api_key", ""),
                    api_secret=SECRETS.get("bybit_api_secret", ""),
                    testnet=bool(SECRETS.get("bybit_testnet", True)),
                )
            except Exception:
                bybit = None
        info = None

        if futures:
            if exchange == "bybit" and bybit is not None:
                ex = bybit.instruments_linear(par)
                rows = (((ex or {}).get("result") or {}).get("list") or [])
                for s in rows:
                    if s.get("symbol") == par:
                        lot = s.get("lotSizeFilter") or {}
                        info = {
                            "filters": [
                                {
                                    "filterType": "LOT_SIZE",
                                    "stepSize": str(lot.get("qtyStep", "0")),
                                    "minQty": str(lot.get("minOrderQty", "0")),
                                },
                                {
                                    "filterType": "MIN_NOTIONAL",
                                    "minNotional": str(lot.get("minNotionalValue", "0")),
                                },
                            ]
                        }
                        break
            else:
                ex = client.futures_exchange_info()
                for s in ex.get("symbols", []):
                    if s.get("symbol") == par:
                        info = s
                        break
        else:
            info = client.get_symbol_info(par)

        if not info:
            return 0, "symbol_info vazio"

        step = None
        min_qty = None
        min_notional = 0.0

        for f in info.get("filters", []):
            if f.get("filterType") in ("LOT_SIZE", "MARKET_LOT_SIZE"):
                step_raw = float(f.get("stepSize", 0) or 0)
                min_qty_raw = float(f.get("minQty", 0) or 0)
                if step is None or (step_raw > 0 and step_raw < step):
                    step = step_raw
                if min_qty is None or (min_qty_raw > 0 and min_qty_raw < min_qty):
                    min_qty = min_qty_raw
            elif f.get("filterType") in ("MIN_NOTIONAL", "NOTIONAL"):
                mn = float(f.get("minNotional", f.get("notional", 0)) or 0)
                if mn > 0:
                    min_notional = mn

        if not step or step <= 0:
            return 0, "stepSize inválido"

        casas = max(0, len(str(step).split(".")[-1].rstrip("0")))
        ajustada = math.floor(float(qtd) / step) * step
        ajustada = round(ajustada, casas)

        if min_qty and ajustada < min_qty:
            return 0, f"abaixo do minQty ({min_qty})"

        if futures and step and min_notional and (ajustada * float(preco)) < min_notional:
            tentativa = round(ajustada + step, casas)
            if (not min_qty or tentativa >= min_qty) and (tentativa * float(preco)) >= min_notional:
                ajustada = tentativa

        if min_notional and (ajustada * float(preco)) < min_notional:
            return 0, f"abaixo do minNotional ({min_notional})"

        if ajustada <= 0:
            return 0, "qtd ajustada zerou"

        return ajustada, ""
    except Exception as e:
        return 0, f"erro ajuste lote: {e}"


def _fetch_df(client, par: str, interval: str, limit: int = 120):
    klines = client.get_klines(symbol=par, interval=interval, limit=limit)
    df = pd.DataFrame(klines, columns=[
        "time", "open", "high", "low", "close", "volume",
        "close_time", "quote_vol", "trades", "taker_base", "taker_quote", "ignore"
    ])
    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = df[col].astype(float)
    df["time"] = pd.to_datetime(df["time"], unit="ms")
    return calcular_indicadores(df)


def _atualizar_fg(sentimento, alpha_news):
    raw_alt = 50
    cls_alt = "Neutro"
    try:
        r = requests.get("https://api.alternative.me/fng/?limit=1", timeout=8)
        d = r.json()["data"][0]
        raw_alt = int(d["value"])
        cls_alt = d["value_classification"]
    except Exception:
        pass
    news_fg = getattr(alpha_news, "fear_value", 50)
    cls_news = getattr(alpha_news, "fear_label", "Neutro")
    combinado = int(max(0, min(100, round(raw_alt * 0.65 + news_fg * 0.35))))
    sentimento.valor = combinado
    sentimento.classificacao = classificar_fg(combinado)
    sentimento.raw_alt = raw_alt
    sentimento.news = news_fg
    sentimento.classificacao_alt = cls_alt
    sentimento.classificacao_news = cls_news
    log.info("📊 Fear & Greed combinado: %s (%s) | alt=%s (%s) | news=%s (%s)",
             sentimento.valor, sentimento.classificacao, raw_alt, cls_alt, news_fg, cls_news)


def _build_ai_context(par, sinal, score, sinais_tf, preco, atr, contexto_mercado,
                      flow_proxy_info, whale_real_info, news_snapshot, sentimento, nlp, rl_acao, risk_plan, posicoes_abertas):
    return {
        "pair": par,
        "regime": {
            "regime": contexto_mercado.get("regime", "indefinido"),
            "range_pos_24h": contexto_mercado.get("range_pos_24h", 0.5),
            "dist_ema21_pct": contexto_mercado.get("dist_ema21_pct", 0.0),
            "atr_ratio": contexto_mercado.get("atr_ratio", 1.0),
        },
        "technical": {
            "base_signal": sinal,
            "score_total": score,
            "setup": "multi_tf_confluence",
            "timeframes": sinais_tf,
            "preco": preco,
            "atr": atr,
        },
        "flow_proxy": flow_proxy_info,
        "whale_real": whale_real_info,
        "news": news_snapshot,
        "sentiment": {
            "fear_composto": sentimento.valor,
            "fear_label": sentimento.classificacao,
            "fear_alt": sentimento.raw_alt,
            "fear_news": sentimento.news,
            "nlp_score": nlp.score,
            "nlp_label": nlp.label,
            "nlp_top_termos": getattr(nlp, "top_termos", []),
        },
        "risk": {
            "capital": None,
            "daily_loss_limit": None,
            "positions_open": posicoes_abertas,
            "plan": risk_plan.as_dict() if hasattr(risk_plan, "as_dict") else dict(risk_plan),
        },
        "rl": {
            "acao": rl_acao,
        },
    }


def _should_block_global(bot_ativo, stop_diario_ativo, stop_trades_ativo, stop_losses_ativo, stop_winrate_ativo,
                         resultado_dia, trades_dia, max_trades_day, losses_seguidos, max_losses_seguidos,
                         winrate_dia, min_winrate_pct):
    if not bot_ativo:
        return "DESLIGADO", "Bot desligado manualmente"
    if stop_diario_ativo:
        return "STOP DIÁRIO", f"Stop diário ativo | perda do dia ${resultado_dia:.2f}"
    if stop_trades_ativo:
        return "LIMITE DE TRADES", f"Máximo de trades do dia atingido ({trades_dia}/{max_trades_day})"
    if stop_losses_ativo:
        return "LOSSES SEGUIDOS", f"Losses seguidos atingidos ({losses_seguidos}/{max_losses_seguidos})"
    if stop_winrate_ativo:
        return "WINRATE STOP", f"Winrate do dia baixo ({winrate_dia:.1f}% < {min_winrate_pct:.1f}%)"
    return "OPERANDO", "Bot operando normalmente"


def run_engine(log_buffer):
    with SECRETS_LOCK:
        exchange = str(SECRETS.get("exchange", "binance")).lower()
        api_key = SECRETS.get("binance_api_key", "")
        api_secret = SECRETS.get("binance_api_secret", "")
        bybit_api_key = SECRETS.get("bybit_api_key", "")
        bybit_api_secret = SECRETS.get("bybit_api_secret", "")
        bybit_testnet = bool(SECRETS.get("bybit_testnet", True))
        usar_testnet = bool(SECRETS.get("usar_testnet", True))
        capital_inicial = float(SECRETS.get("capital_total", 100.0))

    client = Client(api_key, api_secret, testnet=usar_testnet)
    bybit = None
    if exchange == "bybit":
        try:
            bybit = BybitV5(
                api_key=bybit_api_key,
                api_secret=bybit_api_secret,
                testnet=bybit_testnet,
            )
            _pos = bybit.positions_linear("BTCUSDT")
            _wallet = bybit.wallet_balance()
            log.info("✅ Bybit V5 conectada | pos_ret=%s | wallet_ret=%s", _pos.get("retCode"), _wallet.get("retCode"))
        except Exception as e:
            log.error("❌ Falha conexão Bybit V5: %s", e)

    trading_mode = str(SECRETS.get("trading_mode", "spot")).lower()
    futures_leverage = max(1, int(SECRETS.get("futures_leverage", 1) or 1))
    futures_allow_short = bool(SECRETS.get("futures_allow_short", False))
    futures_margin_type = str(SECRETS.get("futures_margin_type", "ISOLATED")).upper()
    futures_entry_usdt = max(1.0, float(SECRETS.get("futures_entry_usdt", 10.0) or 10.0))

    def is_futures():
        return trading_mode == "futures"

    def _spot_usdt_free():
        try:
            bal = client.get_asset_balance(asset="USDT") or {}
            return float(bal.get("free", 0) or 0.0)
        except Exception:
            return 0.0

    def _futures_usdt_available():
        try:
            rows = client.futures_account_balance()
            if isinstance(rows, list):
                for row in rows:
                    if row.get("asset") == "USDT":
                        return float(row.get("availableBalance", row.get("balance", 0)) or 0.0)
            return 0.0
        except Exception:
            return 0.0

    def ensure_futures_margin(needed_usdt):
        try:
            needed_usdt = max(1.0, float(needed_usdt or 0.0))

            if exchange == "bybit":
                if bybit is None:
                    return False, "Bybit não inicializada"
                try:
                    data = bybit.wallet_balance("UNIFIED", "USDT")
                    rows = (((data or {}).get("result") or {}).get("list") or [])
                    avail = 0.0
                    if rows:
                        row = rows[0] or {}
                        for key in ("totalAvailableBalance", "availableToWithdraw", "totalWalletBalance"):
                            val = row.get(key)
                            if val not in (None, "", "0", "0.0"):
                                try:
                                    avail = float(val)
                                    break
                                except Exception:
                                    pass
                        if avail <= 0:
                            coins = row.get("coin") or []
                            if isinstance(coins, list):
                                for c in coins:
                                    if str(c.get("coin", "")).upper() == "USDT":
                                        for key in ("availableToWithdraw", "walletBalance", "equity"):
                                            val = c.get(key)
                                            if val not in (None, "", "0", "0.0"):
                                                try:
                                                    avail = float(val)
                                                    break
                                                except Exception:
                                                    pass
                                        if avail > 0:
                                            break
                except Exception as e:
                    return False, f"Erro lendo saldo Bybit: {e}"

                if avail >= needed_usdt:
                    return True, ""

                return False, f"Saldo Bybit insuficiente p/ nova ordem (avail={avail:.2f}, precisa={needed_usdt:.2f})"

            fut_free = _futures_usdt_available()
            if fut_free >= needed_usdt:
                return True, ""

            spot_free = _spot_usdt_free()
            deficit = round(max(0.0, needed_usdt - fut_free) + 0.25, 2)

            if spot_free < deficit:
                return False, f"Spot USDT insuficiente p/ transferir p/ Futures (spot={spot_free:.2f}, futures={fut_free:.2f}, precisa={needed_usdt:.2f})"

            if usar_testnet:
                return False, "Auto-transfer desativado no testnet"

            resp = client.make_universal_transfer(
                type="MAIN_UMFUTURE",
                asset="USDT",
                amount=str(deficit),
            )
            log.info("💸 Transferência automática Spot->Futures concluída | USDT=%.2f | resp=%s", deficit, resp)
            return True, ""
        except Exception as e:
            return False, f"Erro auto-transfer futures: {e}"

    def configurar_futures_par(symbol):
        mt = "CROSSED" if futures_margin_type in ("CROSS", "CROSSED") else "ISOLATED"
        try:
            client.futures_change_margin_type(symbol=symbol, marginType=mt)
        except Exception:
            pass
        try:
            client.futures_change_leverage(symbol=symbol, leverage=futures_leverage)
        except Exception:
            pass

    agente = AgenteQL()
    gestao = GestaoCapital(capital_inicial)
    sentimento = type("S", (), {
        "valor": 50,
        "classificacao": "Neutro",
        "raw_alt": 50,
        "news": 50,
        "classificacao_alt": "Neutro",
        "classificacao_news": "Neutro"
    })()
    nlp = AnalisadorNLP()
    alpha_news = AlphaNewsManager()
    flow_proxy = FlowProxyDetector()
    whale_real = WhaleRealDetector()
    otimizador = AutoOtimizador()
    ai_engine = ClaudeDecisionEngine()
    risk_engine = RiskEngine()

    posicoes: Dict[str, dict] = {}
    estado_rl: Dict[str, str] = {}
    resultado_dia = 0.0
    dia_atual = date.today()
    trades_dia = 0
    wins_dia = 0
    losses_seguidos = 0
    ciclo = 0

    alpha_news.atualizar(PARES_PADRAO)
    _atualizar_fg(sentimento, alpha_news)
    nlp.atualizar(alpha_news.items)
    atualizar_estado(agente, gestao, sentimento, nlp, flow_proxy, whale_real, alpha_news,
                     posicoes, otimizador, log_buffer, PARES_PADRAO, {}, resultado_dia,
                     trades_dia, wins_dia, losses_seguidos, ai_engine)

    while True:
        try:
            ciclo += 1
            if date.today() != dia_atual:
                dia_atual = date.today()
                resultado_dia = 0.0
                trades_dia = 0
                wins_dia = 0
                losses_seguidos = 0
                log.info("📅 Novo dia detectado | resetando métricas do dia")

            with STATE_LOCK:
                pares_ativos = ESTADO_GLOBAL.get("pares_ativos", PARES_PADRAO)
            with SECRETS_LOCK:
                bot_ativo = bool(SECRETS.get("bot_enabled_manual", True))
                limite_diario = float(SECRETS.get("daily_loss_limit", 50.0))
                max_trades_day = int(SECRETS.get("max_trades_day", 12))
                max_losses_seguidos = int(SECRETS.get("max_losses_seguidos", 3))
                min_winrate_trades = int(SECRETS.get("min_winrate_trades", 6))
                min_winrate_pct = float(SECRETS.get("min_winrate_pct", 35.0))
                preset_atual = str(SECRETS.get("trading_preset", "equilibrado")).lower()

            if ciclo % 30 == 0:
                alpha_news.atualizar(pares_ativos)
                _atualizar_fg(sentimento, alpha_news)
                nlp.atualizar(alpha_news.items)

            if otimizador.deve_otimizar():
                otimizador.otimizar(client)

            # monitoramento das posições abertas
            for par in list(posicoes.keys()):
                pos = posicoes[par]
                try:
                    preco = float(client.get_symbol_ticker(symbol=par)["price"])
                    entrada = float(pos["entrada"])
                    lado = pos["lado"]
                    if lado == "COMPRAR":
                        if preco > float(pos.get("melhor_preco", entrada)):
                            pos["melhor_preco"] = preco
                    else:
                        if float(pos.get("melhor_preco", entrada)) == entrada or preco < float(pos.get("melhor_preco", entrada)):
                            pos["melhor_preco"] = preco

                    try:
                        df_m15 = _fetch_df(client, par, Client.KLINE_INTERVAL_15MINUTE, limit=120)
                        atr_m15 = float(df_m15.iloc[-1]["atr"])
                        risk_engine.update_management(pos, df_m15, atr_m15)
                    except Exception:
                        df_m15 = None

                    pnl_pct = (preco - entrada) / entrada if lado == "COMPRAR" else (entrada - preco) / entrada
                    pnl_usd = pnl_pct * float(pos["qtd"]) * entrada

                    fechar = False
                    if lado == "COMPRAR":
                        fechar = preco <= float(pos["stop"]) or preco >= float(pos["alvo"])
                    else:
                        fechar = preco >= float(pos["stop"]) or preco <= float(pos["alvo"])

                    if fechar:

                        lado_f = "SELL" if lado == "COMPRAR" else "BUY"

                        try:

                            if lado_f == "SELL":

                                qtd_saida = float(pos.get("qtd", 0))

                                if qtd_saida <= 0:

                                    log.error("Erro: qtd invalida para fechar %s: %s", par, pos.get("qtd"))

                                    continue

                    

                                if is_futures():
                                    configurar_futures_par(par)
                                    ordem_saida = client.futures_create_order(
                                        symbol=par,
                                        side=lado_f,
                                        type="MARKET",
                                        quantity=qtd_saida,
                                        reduceOnly=True
                                    )
                                else:
                                    ordem_saida = client.order_market(

                                        symbol=par,

                                        side=lado_f,

                                        quantity=qtd_saida

                                    )

                            else:

                                if is_futures():
                                    configurar_futures_par(par)
                                    ordem_saida = client.futures_create_order(
                                        symbol=par,
                                        side=lado_f,
                                        type="MARKET",
                                        quantity=float(pos.get("qtd", 0)),
                                        reduceOnly=True
                                    )
                                else:
                                    ordem_saida = client.order_market(

                                        symbol=par,

                                        side=lado_f,

                                        quoteOrderQty=get_valor_trade()

                                    )

                    

                        except BinanceAPIException as e:

                            log.error("Erro fechando %s: %s", par, e.message)

                            continue

                        except Exception as e:

                            log.error("Erro inesperado fechando %s: %s", par, str(e))

                            continue

                    

                        status_saida = str(ordem_saida.get("status", "")).upper()

                        if status_saida not in ("FILLED", "PARTIALLY_FILLED"):

                            log.error("Saida de %s nao confirmada. Status: %s | ordem: %s", par, status_saida, ordem_saida)

                            continue

                    

                        resultado_dia += pnl_usd

                        trades_dia += 1

                        if pnl_usd > 0:

                            wins_dia += 1

                            losses_seguidos = 0

                        else:

                            losses_seguidos += 1

                    

                        novo_cap = gestao.capital + pnl_usd

                        gestao.atualizar(novo_cap)

                        gestao.historico_retornos.append(pnl_pct)

                        if par in estado_rl:

                            recompensa = math.log1p(max(-0.99, pnl_pct * 100)) if pnl_usd > 0 else -2.5 * abs(pnl_pct * 100)

                            agente.aprender(estado_rl[par], pos.get("acao_idx", 0), recompensa, estado_rl[par])

                    

                        agente.registrar(pnl_usd, gestao.capital)

                        del posicoes[par]

                        log.info("Trade %s fechado | PnL: $%.4f", par, pnl_usd)
                except Exception as e:
                    log.error("Erro monitorando %s: %s", par, e)

            stop_diario_ativo = resultado_dia <= -limite_diario
            stop_trades_ativo = trades_dia >= max_trades_day
            stop_losses_ativo = losses_seguidos >= max_losses_seguidos
            winrate_dia = (wins_dia / trades_dia * 100.0) if trades_dia > 0 else 0.0
            stop_winrate_ativo = trades_dia >= min_winrate_trades and winrate_dia < min_winrate_pct
            status_label, pause_reason = _should_block_global(
                bot_ativo, stop_diario_ativo, stop_trades_ativo, stop_losses_ativo, stop_winrate_ativo,
                resultado_dia, trades_dia, max_trades_day, losses_seguidos, max_losses_seguidos,
                winrate_dia, min_winrate_pct,
            )
            with STATE_LOCK:
                ESTADO_GLOBAL["bot_status_label"] = status_label
                ESTADO_GLOBAL["bot_pause_reason"] = pause_reason

            sinais_dashboard: Dict[str, dict] = {}

            for par in pares_ativos:
                try:
                    if status_label != "OPERANDO":
                        sinais_dashboard[par] = {"timeframes": {}, "score": 0, "motivo": pause_reason}
                        continue
                    if par in posicoes:
                        sinais_dashboard[par] = {"timeframes": {}, "score": 0, "motivo": "Já existe posição aberta", "posicao_aberta": True}
                        continue
                    if len(posicoes) >= MAX_POSICOES:
                        sinais_dashboard[par] = {"timeframes": {}, "score": 0, "motivo": "Máximo de posições atingido"}
                        continue

                    motivo = "Sem bloqueio"
                    sinal, score, sinais_tf, atr, preco, df_m15 = sinal_multi_tf(client, par)
                    try:
                        df_h1 = _fetch_df(client, par, Client.KLINE_INTERVAL_1HOUR, limit=240)
                    except Exception:
                        df_h1 = None
                    contexto_mercado = calcular_contexto_mercado(df_m15, df_h1, preco, atr)
                    flow_info = flow_proxy.analisar_fluxo(par, df_m15)
                    whale_info = whale_real.analisar(client, par, df_m15, preco)
                    news_snapshot = alpha_news.pair_snapshot(par, desired_action=sinal)

                    sinais_dashboard[par] = {
                        "timeframes": sinais_tf,
                        "score": score,
                        "motivo": motivo,
                        "perfil": classificar_par(par),
                        "flow_proxy": flow_info,
                        "whale": whale_info,
                        "whale_real": whale_info,
                        "whale_score": round(float(whale_info.get("score", 0.0)), 4),
                        "news": news_snapshot,
                        "contexto": contexto_mercado,
                    }

                    if sinal == "AGUARDAR":
                        sinais_dashboard[par]["motivo"] = "Sistema sinalizou AGUARDAR"
                        continue

                    label_nlp = getattr(nlp, "label", "Neutro")
                    score_nlp = float(getattr(nlp, "score", 0.0))
                    if label_nlp == "Bearish" and score_nlp <= -6.0 and sinal == "COMPRAR":
                        sinais_dashboard[par]["motivo"] = f"NLP forte contra compra ({score_nlp:+.2f})"
                        continue
                    if label_nlp == "Bullish" and score_nlp >= 6.0 and sinal == "VENDER":
                        sinais_dashboard[par]["motivo"] = f"NLP forte contra venda ({score_nlp:+.2f})"
                        continue

                    sinal_ajustado, flow_score = flow_proxy.ajustar_sinal(sinal, par, df_m15)
                    sinais_dashboard[par]["flow_proxy_score"] = round(float(flow_score or 0.0), 4)
                    if sinal_ajustado == "AGUARDAR" and sinal != "AGUARDAR":
                        sinais_dashboard[par]["motivo"] = "Flow proxy bloqueou"
                        continue
                    sinal = sinal_ajustado

                    # RL como sugestão, não como dono da decisão
                    estado = agente.codificar_estado(score, sentimento.valor, nlp.score, abs(float(whale_info.get("score", 0.0))) + abs(float(flow_info.get("score", 0.0))))
                    acao_idx = agente.escolher_acao(estado, sinal)
                    rl_acao = agente.ACOES[acao_idx]

                    risk_plan = risk_engine.build_plan(
                        acao=sinal,
                        preco=preco,
                        atr=atr,
                        df_m15=df_m15,
                        contexto=contexto_mercado,
                        flow_proxy=flow_info,
                        whale_real=whale_info,
                        news_snapshot=news_snapshot,
                        preset=preset_atual,
                    )
                    ctx_ai = _build_ai_context(
                        par, sinal, score, sinais_tf, preco, atr, contexto_mercado,
                        flow_info, whale_info, news_snapshot, sentimento, nlp, rl_acao, risk_plan,
                        len(posicoes),
                    )
                    with SECRETS_LOCK:
                        ctx_ai["risk"]["capital"] = float(SECRETS.get("capital_total", 100.0))
                        ctx_ai["risk"]["daily_loss_limit"] = float(SECRETS.get("daily_loss_limit", 50.0))
                        ai_min_conf = float(SECRETS.get("ai_min_confidence", 0.60))
                    decisao_ai = ai_engine.decidir(ctx_ai)
                    sinais_dashboard[par]["claude"] = decisao_ai
                    sinais_dashboard[par]["ai"] = decisao_ai
                    sinais_dashboard[par]["risk_plan"] = risk_plan.as_dict()

                    regime_local = contexto_mercado.get("regime", "range")
                    range_pos_24h = float(contexto_mercado.get("range_pos_24h", 0.5))
                    atr_ratio = float(contexto_mercado.get("atr_ratio", 1.0))
                    if sinal == "COMPRAR" and regime_local == "esticado_cima":
                        sinais_dashboard[par]["motivo"] = "Preço esticado para cima"
                        continue
                    if sinal == "VENDER" and regime_local == "esticado_baixo":
                        sinais_dashboard[par]["motivo"] = "Preço esticado para baixo"
                        continue
                    if sinal == "COMPRAR" and range_pos_24h > 0.92 and atr_ratio > 1.2:
                        sinais_dashboard[par]["motivo"] = f"Compra perto da máxima 24h ({range_pos_24h:.2f})"
                        continue
                    if sinal == "VENDER" and range_pos_24h < 0.08 and atr_ratio > 1.2:
                        sinais_dashboard[par]["motivo"] = f"Venda perto da mínima 24h ({range_pos_24h:.2f})"
                        continue
                    if news_snapshot.get("conflicts_with_trade"):
                        sinais_dashboard[par]["motivo"] = f"Notícia contradiz {sinal}"
                        continue
                    if decisao_ai["acao"] == "AGUARDAR":
                        sinais_dashboard[par]["motivo"] = f"IA: {decisao_ai['motivo']}"
                        continue
                    if decisao_ai["acao"] != sinal:
                        sinais_dashboard[par]["motivo"] = f"IA contradiz técnico ({decisao_ai['acao']} != {sinal})"
                        continue
                    if float(decisao_ai.get("confianca", 0.0)) < ai_min_conf:
                        sinais_dashboard[par]["motivo"] = f"IA confiança baixa ({decisao_ai['confianca']:.2f})"
                        continue

                    perfil_cfg = _perfil_risco_par(par, preset_atual)
                    if is_futures():
                        qtd = float(futures_entry_usdt) / float(preco)
                    else:
                        _, qtd_base = gestao.tamanho(preco, risk_plan.stop)
                        qtd = float(qtd_base) * float(perfil_cfg["size_mult"])
                    qtd, motivo_lote = ajustar_qtd_lote(client, par, qtd, preco, futures=is_futures())
                    sinais_dashboard[par]["risk_profile"] = {**risk_plan.as_dict(), **perfil_cfg, "qtd": qtd}
                    if qtd <= 0:
                        if is_futures():
                            sinais_dashboard[par]["motivo"] = f"Qtd inválida em futures: {motivo_lote or 'sem motivo'}"
                            continue
                        if sinal == "COMPRAR":
                            sinais_dashboard[par]["motivo"] = "Qtd ignorada para BUY via quoteOrderQty"
                            qtd = 0.0
                        else:
                            sinais_dashboard[par]["motivo"] = f"Qtd inválida: {motivo_lote or 'sem motivo'}"
                            continue

                    if is_futures():
                        if sinal == "COMPRAR":
                            lado = "BUY"
                        elif sinal == "VENDER":
                            if not futures_allow_short:
                                sinais_dashboard[par]["motivo"] = "Futures short desativado"
                                continue
                            lado = "SELL"
                        else:
                            sinais_dashboard[par]["motivo"] = f"Sinal inválido para futures: {sinal}"
                            continue
                    else:
                        if sinal != "COMPRAR":
                            sinais_dashboard[par]["motivo"] = f"Spot-only: ignorado {sinal}"
                            continue
                        lado = "BUY"

                    if is_futures():
                        try:
                            if exchange == "bybit" and bybit is not None:
                                pos_real = (((bybit.positions_linear(par) or {}).get("result") or {}).get("list") or [])
                                if isinstance(pos_real, list) and pos_real:
                                    row = pos_real[0]
                                    side_real = str(row.get("side", "") or "").upper()
                                    size_real = float(row.get("size", 0) or 0)
                                    amt = -size_real if side_real == "SELL" else size_real
                                    entry_price_real = float(row.get("avgPrice", 0) or 0)
                                    unrealized_real = float(row.get("unrealisedPnl", 0) or 0)
                                    with STATE_LOCK:
                                        ESTADO_GLOBAL.setdefault("futures_positions", {})
                                        ESTADO_GLOBAL["futures_positions"][par] = {
                                            "positionAmt": amt,
                                            "entryPrice": entry_price_real,
                                            "unRealizedProfit": unrealized_real,
                                        }
                                    if abs(amt) > 0:
                                        sinais_dashboard[par]["motivo"] = f"Posição futures já aberta ({amt})"
                                        continue
                            else:
                                pos_real = client.futures_position_information(symbol=par)
                                if isinstance(pos_real, list) and pos_real:
                                    amt = float(pos_real[0].get("positionAmt", 0) or 0)
                                    entry_price_real = float(pos_real[0].get("entryPrice", 0) or 0)
                                    unrealized_real = float(pos_real[0].get("unRealizedProfit", 0) or 0)
                                    with STATE_LOCK:
                                        ESTADO_GLOBAL.setdefault("futures_positions", {})
                                        ESTADO_GLOBAL["futures_positions"][par] = {
                                            "positionAmt": amt,
                                            "entryPrice": entry_price_real,
                                            "unRealizedProfit": unrealized_real,
                                        }
                                    if abs(amt) > 0:
                                        sinais_dashboard[par]["motivo"] = f"Posição futures já aberta ({amt})"
                                        continue
                        except Exception as e:
                            sinais_dashboard[par]["motivo"] = f"Erro lendo posição futures: {e}"
                            continue

                    try:
                        if is_futures():
                            with STATE_LOCK:
                                ESTADO_GLOBAL["futures_last_attempt"] = {
                                    "pair": par,
                                    "side": lado,
                                    "qtd": qtd,
                                    "preco": preco,
                                    "mode": "futures",
                                }
                        if is_futures():
                            ok_margin, motivo_margin = ensure_futures_margin(max(5.0, float(futures_entry_usdt or 0.0)))
                            if not ok_margin:
                                sinais_dashboard[par]["motivo"] = motivo_margin
                                log.info("⛔ Futures bloqueado %s | motivo=%s", par, motivo_margin)
                                continue
                            log.info("🚀 Tentando ordem %s | lado=%s | qtd=%s | preco=%s", par, lado, qtd, preco)
                            if exchange == "bybit" and bybit is not None:
                                bybit.create_market_order(
                                    symbol=par,
                                    side=lado,
                                    qty=str(qtd),
                                    position_idx=0,
                                    reduce_only=False,
                                )
                            else:
                                configurar_futures_par(par)
                                client.futures_create_order(
                                    symbol=par,
                                    side=lado,
                                    type="MARKET",
                                    quantity=qtd
                                )
                        else:
                            client.order_market(symbol=par, side=lado, quoteOrderQty=get_valor_trade())
                        sinais_dashboard[par]["motivo"] = f"Ordem enviada: {sinal}"
                        risco_inicial = abs(preco - risk_plan.stop)
                        posicoes[par] = {
                            "lado": sinal,
                            "entrada": preco,
                            "stop": risk_plan.stop,
                            "alvo": risk_plan.alvo,
                            "qtd": qtd,
                            "acao_idx": acao_idx,
                            "melhor_preco": preco,
                            "risco_inicial": risco_inicial,
                            "break_even_ativo": False,
                            "trailing_ativo": False,
                            "break_even_trigger_rr": risk_plan.break_even_trigger_rr,
                            "trailing_trigger_rr": risk_plan.trailing_trigger_rr,
                            "trailing_offset_rr": risk_plan.trailing_offset_rr,
                            "trailing_mode": risk_plan.trailing_mode,
                            "flow_proxy": flow_info,
                            "whale_real": whale_info,
                            "news": news_snapshot,
                            "risk_plan": risk_plan.as_dict(),
                        }
                        estado_rl[par] = estado
                        log.info("✅ [%s] %s %s @ $%.2f | Stop=%s Alvo=%s | Score=%+d", par, sinal, qtd, preco, risk_plan.stop, risk_plan.alvo, score)
                    except BinanceAPIException as e:
                        sinais_dashboard[par]["motivo"] = f"Erro Binance: {e.message}"
                        log.error("❌ [%s] %s", par, e.message)

                except Exception as e:
                    sinais_dashboard[par] = {"timeframes": {}, "score": 0, "motivo": f"Erro interno: {e}"}
                    log.error("Erro %s: %s", par, e)
                    time.sleep(1)

            atualizar_estado(agente, gestao, sentimento, nlp, flow_proxy, whale_real, alpha_news,
                             posicoes, otimizador, log_buffer, pares_ativos, sinais_dashboard,
                             resultado_dia, trades_dia, wins_dia, losses_seguidos, ai_engine)
            time.sleep(INTERVALO)

        except KeyboardInterrupt:
            with STATE_LOCK:
                ESTADO_GLOBAL["status"] = "encerrado"
            log.info("🔴 Bot encerrado.")
            break
        except Exception as e:
            log.error("❌ Erro geral: %s", e)
            time.sleep(30)



        # ===== SAFE_HEDGE_AI =====
        try:
            if "ultimo_sinal" in estado:
                for par, sinal in estado["ultimo_sinal"].items():

                    ctx_ai = {
                        "technical": {
                            "score": sinal.get("score", 0),
                            "direcao": sinal.get("direcao", "")
                        },
                        "flow_proxy": sinal.get("flow_proxy", {}),
                        "whale_real": sinal.get("whale_real", {}),
                        "news": sinal.get("news", {}),
                        "risk": sinal.get("risk", {})
                    }

                    ai_out = AI_ENGINE.decidir(ctx_ai)

                    if ai_out:
                        estado["ai_last_decision"] = ai_out

                        if ai_out.get("acao") == "AGUARDAR":
                            sinal["direcao"] = "AGUARDAR"
                            sinal["motivo"] = str(sinal.get("motivo","")) + " | IA bloqueou"

                        elif ai_out.get("acao") == sinal.get("direcao"):
                            sinal["score"] = sinal.get("score",0) + ai_out.get("confianca",0)*2

                        else:
                            sinal["direcao"] = "AGUARDAR"
                            sinal["motivo"] = str(sinal.get("motivo","")) + " | IA conflito"

        except Exception:
            pass
        # =========================


        # ===== ANTI_MANIPULATION_BLOCK =====
        try:
            if "ultimo_sinal" in estado:
                for par, sinal in estado["ultimo_sinal"].items():

                    flow = sinal.get("flow_proxy", {})
                    whale = sinal.get("whale_real", {})
                    score = sinal.get("score", 0)

                    delta = flow.get("delta_ratio", 0)
                    book = flow.get("book_imbalance", 0)
                    price_change = flow.get("price_change_pct", 0)

                    # 🚨 FAKE BREAKOUT
                    if abs(delta) > 0.2 and abs(book) < 0.05:
                        sinal["direcao"] = "AGUARDAR"
                        sinal["motivo"] = str(sinal.get("motivo","")) + " | fake breakout detectado"

                    # 🚨 STOP HUNT
                    elif abs(price_change) > 1.2 and abs(delta) < 0.1:
                        sinal["direcao"] = "AGUARDAR"
                        sinal["motivo"] = str(sinal.get("motivo","")) + " | stop hunt detectado"

                    # 🚨 ABSORÇÃO CONTRÁRIA
                    elif delta > 0.2 and book < -0.1:
                        sinal["direcao"] = "AGUARDAR"
                        sinal["motivo"] = str(sinal.get("motivo","")) + " | absorção institucional"

                    elif delta < -0.2 and book > 0.1:
                        sinal["direcao"] = "AGUARDAR"
                        sinal["motivo"] = str(sinal.get("motivo","")) + " | absorção institucional"

        except Exception:
            pass
        # ==================================
