import json
import time
import hmac
import hashlib
from urllib.parse import urlencode

import requests


class BybitV5:
    def __init__(self, api_key: str, api_secret: str, testnet: bool = True, recv_window: int = 5000):
        self.api_key = api_key or ""
        self.api_secret = api_secret or ""
        self.testnet = bool(testnet)
        self.recv_window = str(recv_window)
        self.base = "https://api-testnet.bybit.com" if self.testnet else "https://api.bybit.com"

    def _sign_get(self, params: dict):
        ts = str(int(time.time() * 1000))
        query = urlencode(params)
        payload = f"{ts}{self.api_key}{self.recv_window}{query}"
        sig = hmac.new(self.api_secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
        headers = {
            "X-BAPI-API-KEY": self.api_key,
            "X-BAPI-TIMESTAMP": ts,
            "X-BAPI-RECV-WINDOW": self.recv_window,
            "X-BAPI-SIGN": sig,
        }
        return query, headers

    def _sign_post(self, body: dict):
        ts = str(int(time.time() * 1000))
        body_s = json.dumps(body, separators=(",", ":"))
        payload = f"{ts}{self.api_key}{self.recv_window}{body_s}"
        sig = hmac.new(self.api_secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
        headers = {
            "X-BAPI-API-KEY": self.api_key,
            "X-BAPI-TIMESTAMP": ts,
            "X-BAPI-RECV-WINDOW": self.recv_window,
            "X-BAPI-SIGN": sig,
            "Content-Type": "application/json",
        }
        return body_s, headers

    def public_get(self, path: str, params: dict | None = None):
        r = requests.get(f"{self.base}{path}", params=params or {}, timeout=20)
        r.raise_for_status()
        return r.json()

    def private_get(self, path: str, params: dict | None = None):
        params = params or {}
        query, headers = self._sign_get(params)
        url = f"{self.base}{path}"
        if query:
            url = f"{url}?{query}"
        r = requests.get(url, headers=headers, timeout=20)
        r.raise_for_status()
        data = r.json()
        if data.get("retCode") != 0:
            raise RuntimeError(f"Bybit GET erro: {data}")
        return data

    def private_post(self, path: str, body: dict | None = None):
        body = body or {}
        body_s, headers = self._sign_post(body)
        r = requests.post(f"{self.base}{path}", headers=headers, data=body_s, timeout=20)
        r.raise_for_status()
        data = r.json()
        if data.get("retCode") != 0:
            raise RuntimeError(f"Bybit POST erro: {data}")
        return data

    def instruments_linear(self, symbol: str | None = None):
        params = {"category": "linear"}
        if symbol:
            params["symbol"] = symbol
        return self.public_get("/v5/market/instruments-info", params)

    def positions_linear(self, symbol: str | None = None):
        params = {"category": "linear"}
        if symbol:
            params["symbol"] = symbol
        return self.private_get("/v5/position/list", params)

    def wallet_balance(self, account_type: str = "UNIFIED", coin: str = "USDT"):
        params = {"accountType": account_type, "coin": coin}
        return self.private_get("/v5/account/wallet-balance", params)

    def create_market_order(self, symbol: str, side: str, qty: str, position_idx: int = 0, reduce_only: bool = False):
        body = {
            "category": "linear",
            "symbol": symbol,
            "side": side,
            "orderType": "Market",
            "qty": str(qty),
            "positionIdx": position_idx,
        }
        if reduce_only:
            body["reduceOnly"] = True
        return self.private_post("/v5/order/create", body)
